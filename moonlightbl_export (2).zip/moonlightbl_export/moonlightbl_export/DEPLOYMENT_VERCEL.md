# 🚀 Deployment de MoonlightBL en Vercel

## 📋 Pasos Fáciles para Deployment

### Paso 1: Preparar el Repositorio

```bash
# Navega a la carpeta del proyecto
cd moonlightbl_export

# Inicializa Git si no está hecho
git init

# Agrega todos los archivos
git add .

# Haz el primer commit
git commit -m "MoonlightBL listo para Vercel"
```

### Paso 2: Subir a GitHub/GitLab

**Opción A: GitHub**
1. Ve a [github.com](https://github.com)
2. Crea un nuevo repositorio llamado `moonlightbl`
3. Sigue las instrucciones de GitHub para subir tu código:
   ```bash
   git remote add origin https://github.com/tu-usuario/moonlightbl.git
   git branch -M main
   git push -u origin main
   ```

**Opción B: GitLab**
1. Ve a [gitlab.com](https://gitlab.com)
2. Crea un nuevo proyecto llamado `moonlightbl`
3. Sube tu código:
   ```bash
   git remote add origin https://gitlab.com/tu-usuario/moonlightbl.git
   git branch -M main
   git push -u origin main
   ```

### Paso 3: Deployment en Vercel

1. **Ve a [vercel.com](https://vercel.com)**
2. **Inicia sesión con tu cuenta de GitHub/GitLab**
3. **Haz clic en "New Project"**
4. **Importa tu repositorio `moonlightbl`**
5. **Vercel detectará automáticamente:**
   - ✅ Framework: React (frontend)
   - ✅ Python Runtime (backend)
   - ✅ Build settings
   - ✅ Serverless Functions

### Paso 4: Configurar Variables de Entorno

En el dashboard de Vercel, ve a **Settings → Environment Variables** y agrega:

```
JWT_SECRET=moonlightbl_prod_secret_key_x7k9m2p4q8r1s5t0u3v6w9y2z5a8b1c4
```

### Paso 5: Deployment Automático

¡Listo! Vercel hará deployment automáticamente y te dará tus URLs:

🎯 **URLs que recibirás:**
- **Sitio Principal**: `https://moonlightbl-tu-usuario.vercel.app`
- **Panel Admin**: `https://moonlightbl-tu-usuario.vercel.app/admin`
- **API Backend**: `https://moonlightbl-tu-usuario.vercel.app/api`

## 🛠️ Script Automático (Opcional)

Si quieres usar el script automático:

```bash
# Hazlo ejecutable
chmod +x deploy_vercel.sh

# Ejecútalo
./deploy_vercel.sh
```

## 🔧 Solución de Problemas Comunes

### Si Vercel no detecta el framework:

Asegúrate que tu `vercel.json` esté en la raíz del proyecto:

```json
{
  "version": 2,
  "framework": "create-react-app"
}
```

### Si hay errores de build:

Verifica que todas las dependencias estén instaladas:

```bash
# Frontend
cd frontend && npm install

# Backend  
cd backend && pip install -r requirements.txt
```

### Si las URLs no funcionan:

1. Espera unos minutos a que el deployment termine
2. Revisa el dashboard de Vercel para ver el estado
3. Las URLs pueden tardar unos minutos en activarse

## 🎉 ¡Listo para Vercel!

Una vez completado estos pasos, tu proyecto MoonlightBL estará:

- ✅ **100% Funcional** en Vercel
- ✅ **URLs automáticas** que se ajustan solas
- ✅ **Base de datos SQLite** persistente
- ✅ **Panel administrativo** completo
- ✅ **Sistema de uploads** funcionando
- ✅ **Zero configuration** necesario

**¡Tu plataforma BL/LGBT estará lista para el mundo!** 🌈🏳‍🌈
