from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import hashlib
import re
import json
import asyncio
from collections import defaultdict

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Data storage paths
DATA_DIR = ROOT_DIR / 'data'
DATA_DIR.mkdir(exist_ok=True)

# JSON file paths
CONTENTS_FILE = DATA_DIR / 'contents.json'
SEASONS_FILE = DATA_DIR / 'seasons.json'
EPISODES_FILE = DATA_DIR / 'episodes.json'
CAROUSEL_FILE = DATA_DIR / 'carousel.json'
LOGIN_ATTEMPTS_FILE = DATA_DIR / 'login_attempts.json'
VIEW_STATS_FILE = DATA_DIR / 'view_stats.json'
AUDIT_LOGS_FILE = DATA_DIR / 'audit_logs.json'
CONTACT_MESSAGES_FILE = DATA_DIR / 'contact_messages.json'

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET')
if not JWT_SECRET:
    raise ValueError("JWT_SECRET environment variable is required")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# Fixed admin credentials
ADMIN_USERNAME = "ADMINBL"
ADMIN_PASSWORD_HASH = hashlib.sha256("86@$#&bihutrfcñpKGe.jobw@bl".encode()).hexdigest()

# Create the main app
app = FastAPI(title="MoonlightBL API")
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==================== JSON STORAGE HELPERS ====================

class JSONStorage:
    @staticmethod
    async def load_data(file_path: Path) -> List[Dict]:
        if not file_path.exists():
            return []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []
    
    @staticmethod
    async def save_data(file_path: Path, data: List[Dict]):
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
    
    @staticmethod
    async def add_item(file_path: Path, item: Dict) -> Dict:
        data = await JSONStorage.load_data(file_path)
        data.append(item)
        await JSONStorage.save_data(file_path, data)
        return item
    
    @staticmethod
    async def update_item(file_path: Path, item_id: str, updates: Dict) -> Optional[Dict]:
        data = await JSONStorage.load_data(file_path)
        for i, item in enumerate(data):
            if item.get('id') == item_id:
                item.update(updates)
                item['updated_at'] = datetime.now(timezone.utc).isoformat()
                data[i] = item
                await JSONStorage.save_data(file_path, data)
                return item
        return None
    
    @staticmethod
    async def delete_item(file_path: Path, item_id: str) -> bool:
        data = await JSONStorage.load_data(file_path)
        original_length = len(data)
        data = [item for item in data if item.get('id') != item_id]
        if len(data) < original_length:
            await JSONStorage.save_data(file_path, data)
            return True
        return False
    
    @staticmethod
    async def find_item(file_path: Path, **filters) -> Optional[Dict]:
        data = await JSONStorage.load_data(file_path)
        for item in data:
            match = True
            for key, value in filters.items():
                if item.get(key) != value:
                    match = False
                    break
            if match:
                return item
        return None
    
    @staticmethod
    async def find_items(file_path: Path, **filters) -> List[Dict]:
        data = await JSONStorage.load_data(file_path)
        results = []
        for item in data:
            match = True
            for key, value in filters.items():
                if key == '$or':
                    or_match = False
                    for or_condition in value:
                        condition_match = True
                        for or_key, or_value in or_condition.items():
                            if isinstance(or_value, dict) and '$regex' in or_value:
                                import re
                                pattern = or_value['$regex']
                                options = or_value.get('$options', '')
                                flags = re.IGNORECASE if 'i' in options else 0
                                if not re.search(pattern, str(item.get(or_key, '')), flags):
                                    condition_match = False
                                    break
                            elif item.get(or_key) != or_value:
                                condition_match = False
                                break
                        if condition_match:
                            or_match = True
                            break
                    if not or_match:
                        match = False
                        break
                elif isinstance(value, dict) and '$in' in value:
                    if item.get(key) not in value['$in']:
                        match = False
                        break
                elif item.get(key) != value:
                    match = False
                    break
            if match:
                results.append(item)
        return results

# ==================== MODELS ====================

class LoginRequest(BaseModel):
    username: str
    password: str
    remember_me: bool = False

class LoginResponse(BaseModel):
    token: str
    expires_at: str

class ServerLink(BaseModel):
    name: str  # Nombre del servidor (ok.ru, streamtape, etc.)
    url: str  # URL completa o código embed
    embed_type: str = "iframe"  # iframe | embed | mp4 | shortcode
    is_active: bool = True
    subtitles: Optional[str] = None  # Idioma de subtítulos
    audio: Optional[str] = None  # Idioma de audio
    quality: Optional[str] = None  # 480p, 720p, 1080p, etc.
    order: int = 0  # Orden de preferencia

class EpisodeBase(BaseModel):
    number: int
    title: str
    slug: str
    custom_url: Optional[str] = None  # URL personalizada opcional
    synopsis: Optional[str] = None
    duration: Optional[int] = None
    poster: Optional[str] = None
    thumbnail: Optional[str] = None
    servers: List[ServerLink] = []
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: str = "pending"  # pending | published

class EpisodeCreate(EpisodeBase):
    season_id: Optional[str] = None
    content_id: Optional[str] = None

class EpisodeUpdate(BaseModel):
    number: Optional[int] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    custom_url: Optional[str] = None
    synopsis: Optional[str] = None
    duration: Optional[int] = None
    poster: Optional[str] = None
    thumbnail: Optional[str] = None
    servers: Optional[List[ServerLink]] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: Optional[str] = None

class Episode(EpisodeBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    season_id: str
    content_id: str
    views: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SeasonBase(BaseModel):
    number: int
    title: Optional[str] = None
    slug: str
    custom_url: Optional[str] = None  # URL personalizada opcional
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: str = "pending"

class SeasonCreate(SeasonBase):
    content_id: Optional[str] = None

class SeasonUpdate(BaseModel):
    number: Optional[int] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    custom_url: Optional[str] = None
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: Optional[str] = None

class Season(SeasonBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content_id: str
    episode_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ContentBase(BaseModel):
    content_type: str  # serie | miniserie | pelicula | anime
    title: str
    slug: str
    year: Optional[int] = None
    synopsis: Optional[str] = None
    genres: List[str] = []
    tags: List[str] = []
    rating: Optional[float] = None
    production_company: Optional[str] = None
    producer: Optional[str] = None
    cast: List[str] = []
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    gallery: List[str] = []
    trailer_url: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    country: Optional[str] = None
    status: str = "pending"  # pending | published
    is_featured: bool = False
    is_trending: bool = False
    is_popular: bool = False
    servers: List[ServerLink] = []  # For movies only

class ContentCreate(ContentBase):
    pass

class ContentUpdate(BaseModel):
    content_type: Optional[str] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    genres: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    rating: Optional[float] = None
    production_company: Optional[str] = None
    producer: Optional[str] = None
    cast: Optional[List[str]] = None
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    gallery: Optional[List[str]] = None
    trailer_url: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    country: Optional[str] = None
    status: Optional[str] = None
    is_featured: Optional[bool] = None
    is_trending: Optional[bool] = None
    is_popular: Optional[bool] = None
    servers: Optional[List[ServerLink]] = None

class Content(ContentBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    views: int = 0
    season_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CarouselItem(BaseModel):
    content_id: str
    order: int

class CarouselConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    items: List[CarouselItem] = []
    auto_populate: bool = True
    auto_type: str = "popular"  # popular | trending | latest
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ViewStat(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content_id: str
    episode_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    user_agent: Optional[str] = None
    ip_hash: Optional[str] = None

class AuditLog(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    action: str
    entity_type: str
    entity_id: str
    changes: Dict[str, Any] = {}
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    username: str = "ADMINBL"

class LoginAttempt(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    success: bool
    ip_hash: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ContactMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: str
    subject: str
    message: str
    read: bool = False
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# ==================== AUTH HELPERS ====================

def create_jwt_token(username: str, remember_me: bool = False) -> tuple:
    expiration = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS * (7 if remember_me else 1))
    payload = {
        "sub": username,
        "exp": expiration,
        "iat": datetime.now(timezone.utc)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token, expiration

async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
        if username != ADMIN_USERNAME:
            raise HTTPException(status_code=401, detail="Token inválido")
        return username
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expirado")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")

def generate_slug(title: str) -> str:
    slug = title.lower()
    slug = re.sub(r'[áàäâ]', 'a', slug)
    slug = re.sub(r'[éèëê]', 'e', slug)
    slug = re.sub(r'[íìïî]', 'i', slug)
    slug = re.sub(r'[óòöô]', 'o', slug)
    slug = re.sub(r'[úùüû]', 'u', slug)
    slug = re.sub(r'[ñ]', 'n', slug)
    slug = re.sub(r'[^a-z0-9\s-]', '', slug)
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = re.sub(r'-+', '-', slug)
    return slug.strip('-')

# ==================== AUTH ROUTES ====================

@api_router.post("/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    # Check failed attempts
    five_minutes_ago = datetime.now(timezone.utc) - timedelta(minutes=5)
    login_attempts = await JSONStorage.load_data(LOGIN_ATTEMPTS_FILE)
    
    recent_failures = [
        attempt for attempt in login_attempts
        if attempt['username'] == request.username and 
           not attempt['success'] and 
           datetime.fromisoformat(attempt['timestamp'].replace('Z', '+00:00')) >= five_minutes_ago
    ]
    
    if len(recent_failures) >= 5:
        raise HTTPException(status_code=429, detail="Demasiados intentos fallidos. Intente de nuevo más tarde.")
    
    password_hash = hashlib.sha256(request.password.encode()).hexdigest()
    
    if request.username != ADMIN_USERNAME or password_hash != ADMIN_PASSWORD_HASH:
        # Log failed attempt
        attempt = LoginAttempt(username=request.username, success=False)
        await JSONStorage.add_item(LOGIN_ATTEMPTS_FILE, attempt.model_dump())
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    
    # Log successful attempt
    attempt = LoginAttempt(username=request.username, success=True)
    await JSONStorage.add_item(LOGIN_ATTEMPTS_FILE, attempt.model_dump())
    
    token, expires_at = create_jwt_token(request.username, request.remember_me)
    return LoginResponse(token=token, expires_at=expires_at.isoformat())

@api_router.get("/auth/verify")
async def verify_auth(username: str = Depends(verify_token)):
    return {"valid": True, "username": username}

# ==================== PUBLIC ROUTES ====================

@api_router.get("/")
async def root():
    return {"message": "MoonlightBL API v1.0 (JSON Storage)"}

@api_router.get("/contents", response_model=List[dict])
async def get_contents(
    content_type: Optional[str] = None,
    status: str = "published",
    genre: Optional[str] = None,
    year: Optional[int] = None,
    country: Optional[str] = None,
    search: Optional[str] = None,
    is_featured: Optional[bool] = None,
    is_trending: Optional[bool] = None,
    is_popular: Optional[bool] = None,
    limit: int = Query(default=20, le=100),
    skip: int = 0,
    sort_by: str = "created_at",
    sort_order: str = "desc"
):
    # Build query filters
    filters = {"status": status}
    
    if content_type:
        filters["content_type"] = content_type
    if genre:
        # For JSON storage, we need to handle genres array differently
        contents = await JSONStorage.load_data(CONTENTS_FILE)
        filtered_contents = []
        for content in contents:
            if content.get("status") != status:
                continue
            if content_type and content.get("content_type") != content_type:
                continue
            if year and content.get("year") != year:
                continue
            if country and content.get("country") != country:
                continue
            if is_featured is not None and content.get("is_featured") != is_featured:
                continue
            if is_trending is not None and content.get("is_trending") != is_trending:
                continue
            if is_popular is not None and content.get("is_popular") != is_popular:
                continue
            if genre and genre not in content.get("genres", []):
                continue
            if search:
                search_lower = search.lower()
                title_match = search_lower in content.get("title", "").lower()
                synopsis_match = search_lower in content.get("synopsis", "").lower()
                tags_match = search_lower in [tag.lower() for tag in content.get("tags", [])]
                cast_match = search_lower in " ".join(content.get("cast", [])).lower()
                if not (title_match or synopsis_match or tags_match or cast_match):
                    continue
            filtered_contents.append(content)
        
        # Sort results
        reverse = sort_order == "desc"
        filtered_contents.sort(key=lambda x: x.get(sort_by, ""), reverse=reverse)
        
        # Apply pagination
        return filtered_contents[skip:skip + limit]
    
    # If no genre filter, use simple filtering
    contents = await JSONStorage.find_items(CONTENTS_FILE, **filters)
    
    # Apply other filters
    if year:
        contents = [c for c in contents if c.get("year") == year]
    if country:
        contents = [c for c in contents if c.get("country") == country]
    if is_featured is not None:
        contents = [c for c in contents if c.get("is_featured") == is_featured]
    if is_trending is not None:
        contents = [c for c in contents if c.get("is_trending") == is_trending]
    if is_popular is not None:
        contents = [c for c in contents if c.get("is_popular") == is_popular]
    
    # Sort results
    reverse = sort_order == "desc"
    contents.sort(key=lambda x: x.get(sort_by, ""), reverse=reverse)
    
    # Apply pagination
    return contents[skip:skip + limit]

@api_router.get("/contents/{slug}", response_model=dict)
async def get_content_by_slug(slug: str):
    content = await JSONStorage.find_item(CONTENTS_FILE, slug=slug, status="published")
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    return content

@api_router.get("/contents/{slug}/seasons", response_model=List[dict])
async def get_content_seasons(slug: str):
    content = await JSONStorage.find_item(CONTENTS_FILE, slug=slug)
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    seasons = await JSONStorage.find_items(SEASONS_FILE, content_id=content['id'])
    seasons.sort(key=lambda x: x.get('number', 0))
    return seasons

@api_router.get("/seasons/{season_id}/episodes", response_model=List[dict])
async def get_season_episodes(season_id: str):
    season = await JSONStorage.find_item(SEASONS_FILE, id=season_id)
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    episodes = await JSONStorage.find_items(EPISODES_FILE, season_id=season_id, status="published")
    episodes.sort(key=lambda x: x.get('number', 0))
    return episodes

@api_router.get("/episodes/{slug}", response_model=dict)
async def get_episode_by_slug(slug: str):
    episode = await JSONStorage.find_item(EPISODES_FILE, slug=slug, status="published")
    if not episode:
        raise HTTPException(status_code=404, detail="Episodio no encontrado")
    
    # Increment view count
    await JSONStorage.update_item(EPISODES_FILE, episode['id'], {"views": episode.get("views", 0) + 1})
    
    # Log view stat
    view_stat = ViewStat(content_id=episode['content_id'], episode_id=episode['id'])
    await JSONStorage.add_item(VIEW_STATS_FILE, view_stat.model_dump())
    
    return episode

@api_router.get("/carousel", response_model=List[dict])
async def get_carousel():
    carousel_data = await JSONStorage.load_data(CAROUSEL_FILE)
    
    if not carousel_data:
        return []
    
    carousel = carousel_data[0]  # Get first (and only) carousel config
    
    if carousel.get("auto_populate", True):
        # Auto-populate based on type
        auto_type = carousel.get("auto_type", "popular")
        contents = await JSONStorage.find_items(CONTENTS_FILE, status="published")
        
        if auto_type == "popular":
            filtered_contents = [c for c in contents if c.get("is_popular", False)]
        elif auto_type == "trending":
            filtered_contents = [c for c in contents if c.get("is_trending", False)]
        else:  # latest
            filtered_contents = sorted(contents, key=lambda x: x.get("created_at", ""), reverse=True)
        
        # Return top 10
        return filtered_contents[:10]
    else:
        # Return manually configured items
        items = carousel.get("items", [])
        result = []
        for item in items:
            content = await JSONStorage.find_item(CONTENTS_FILE, id=item["content_id"])
            if content and content.get("status") == "published":
                result.append(content)
        return result

# ==================== ADMIN ROUTES ====================

@api_router.get("/admin/stats")
async def get_admin_stats(username: str = Depends(verify_token)):
    contents = await JSONStorage.load_data(CONTENTS_FILE)
    seasons = await JSONStorage.load_data(SEASONS_FILE)
    episodes = await JSONStorage.load_data(EPISODES_FILE)
    view_stats = await JSONStorage.load_data(VIEW_STATS_FILE)
    
    total_views = sum(item.get("views", 0) for item in contents + episodes)
    
    content_stats = defaultdict(lambda: 0)
    for content in contents:
        content_stats[content.get("content_type", "unknown")] += 1
    
    return {
        "total_contents": len(contents),
        "total_seasons": len(seasons),
        "total_episodes": len(episodes),
        "total_views": total_views,
        "content_by_type": dict(content_stats),
        "recent_views": len([v for v in view_stats if datetime.fromisoformat(v["timestamp"].replace('Z', '+00:00')) > datetime.now(timezone.utc) - timedelta(days=7)])
    }

@api_router.get("/admin/contents", response_model=List[dict])
async def get_admin_contents(
    content_type: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(default=50, le=100),
    skip: int = 0,
    username: str = Depends(verify_token)
):
    filters = {}
    if content_type:
        filters["content_type"] = content_type
    if status:
        filters["status"] = status
    
    contents = await JSONStorage.load_data(CONTENTS_FILE)
    
    # Apply filters
    filtered_contents = []
    for content in contents:
        match = True
        for key, value in filters.items():
            if content.get(key) != value:
                match = False
                break
        if not match:
            continue
        
        if search:
            search_lower = search.lower()
            if not (search_lower in content.get("title", "").lower() or
                   search_lower in content.get("synopsis", "").lower()):
                continue
        
        filtered_contents.append(content)
    
    # Sort by created_at desc
    filtered_contents.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    
    return filtered_contents[skip:skip + limit]

@api_router.post("/admin/contents", response_model=dict)
async def create_admin_content(content: ContentCreate, username: str = Depends(verify_token)):
    # Check if slug already exists
    existing = await JSONStorage.find_item(CONTENTS_FILE, slug=content.slug)
    if existing:
        raise HTTPException(status_code=400, detail="Slug ya existe")
    
    content_data = content.model_dump()
    content_data["id"] = str(uuid.uuid4())
    content_data["views"] = 0
    content_data["season_count"] = 0
    content_data["created_at"] = datetime.now(timezone.utc).isoformat()
    content_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    created_content = await JSONStorage.add_item(CONTENTS_FILE, content_data)
    
    # Log action
    audit_log = AuditLog(action="create", entity_type="content", entity_id=created_content["id"], username=username)
    await JSONStorage.add_item(AUDIT_LOGS_FILE, audit_log.model_dump())
    
    return created_content

@api_router.put("/admin/contents/{content_id}", response_model=dict)
async def update_admin_content(content_id: str, updates: ContentUpdate, username: str = Depends(verify_token)):
    content = await JSONStorage.find_item(CONTENTS_FILE, id=content_id)
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    update_data = updates.model_dump(exclude_unset=True)
    updated_content = await JSONStorage.update_item(CONTENTS_FILE, content_id, update_data)
    
    if updated_content:
        # Log action
        audit_log = AuditLog(action="update", entity_type="content", entity_id=content_id, changes=update_data, username=username)
        await JSONStorage.add_item(AUDIT_LOGS_FILE, audit_log.model_dump())
        
        return updated_content
    
    raise HTTPException(status_code=500, detail="Error al actualizar contenido")

@api_router.delete("/admin/contents/{content_id}")
async def delete_admin_content(content_id: str, username: str = Depends(verify_token)):
    content = await JSONStorage.find_item(CONTENTS_FILE, id=content_id)
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    # Delete related seasons and episodes
    seasons = await JSONStorage.find_items(SEASONS_FILE, content_id=content_id)
    for season in seasons:
        # Delete episodes of this season
        episodes = await JSONStorage.find_items(EPISODES_FILE, season_id=season["id"])
        for episode in episodes:
            await JSONStorage.delete_item(EPISODES_FILE, episode["id"])
        
        # Delete season
        await JSONStorage.delete_item(SEASONS_FILE, season["id"])
    
    # Delete content
    success = await JSONStorage.delete_item(CONTENTS_FILE, content_id)
    
    if success:
        # Log action
        audit_log = AuditLog(action="delete", entity_type="content", entity_id=content_id, username=username)
        await JSONStorage.add_item(AUDIT_LOGS_FILE, audit_log.model_dump())
        
        return {"message": "Contenido eliminado correctamente"}
    
    raise HTTPException(status_code=500, detail="Error al eliminar contenido")

# Similar routes for seasons and episodes...

@api_router.get("/admin/seasons", response_model=List[dict])
async def get_admin_seasons(content_id: Optional[str] = None, username: str = Depends(verify_token)):
    if content_id:
        seasons = await JSONStorage.find_items(SEASONS_FILE, content_id=content_id)
    else:
        seasons = await JSONStorage.load_data(SEASONS_FILE)
    
    seasons.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return seasons

@api_router.post("/admin/seasons", response_model=dict)
async def create_admin_season(season: SeasonCreate, username: str = Depends(verify_token)):
    # Check if slug already exists for this content
    if season.content_id:
        existing = await JSONStorage.find_item(SEASONS_FILE, slug=season.slug, content_id=season.content_id)
        if existing:
            raise HTTPException(status_code=400, detail="Slug ya existe para este contenido")
    
    season_data = season.model_dump()
    season_data["id"] = str(uuid.uuid4())
    season_data["episode_count"] = 0
    season_data["created_at"] = datetime.now(timezone.utc).isoformat()
    season_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    created_season = await JSONStorage.add_item(SEASONS_FILE, season_data)
    
    # Update content season count
    if season.content_id:
        seasons = await JSONStorage.find_items(SEASONS_FILE, content_id=season.content_id)
        await JSONStorage.update_item(CONTENTS_FILE, season.content_id, {"season_count": len(seasons)})
    
    # Log action
    audit_log = AuditLog(action="create", entity_type="season", entity_id=created_season["id"], username=username)
    await JSONStorage.add_item(AUDIT_LOGS_FILE, audit_log.model_dump())
    
    return created_season

@api_router.get("/admin/episodes", response_model=List[dict])
async def get_admin_episodes(season_id: Optional[str] = None, username: str = Depends(verify_token)):
    if season_id:
        episodes = await JSONStorage.find_items(EPISODES_FILE, season_id=season_id)
    else:
        episodes = await JSONStorage.load_data(EPISODES_FILE)
    
    episodes.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return episodes

@api_router.post("/admin/episodes", response_model=dict)
async def create_admin_episode(episode: EpisodeCreate, username: str = Depends(verify_token)):
    # Check if slug already exists for this season
    if episode.season_id:
        existing = await JSONStorage.find_item(EPISODES_FILE, slug=episode.slug, season_id=episode.season_id)
        if existing:
            raise HTTPException(status_code=400, detail="Slug ya existe para esta temporada")
    
    episode_data = episode.model_dump()
    episode_data["id"] = str(uuid.uuid4())
    episode_data["views"] = 0
    episode_data["created_at"] = datetime.now(timezone.utc).isoformat()
    episode_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    created_episode = await JSONStorage.add_item(EPISODES_FILE, episode_data)
    
    # Update season episode count
    if episode.season_id:
        episodes = await JSONStorage.find_items(EPISODES_FILE, season_id=episode.season_id)
        await JSONStorage.update_item(SEASONS_FILE, episode.season_id, {"episode_count": len(episodes)})
    
    # Log action
    audit_log = AuditLog(action="create", entity_type="episode", entity_id=created_episode["id"], username=username)
    await JSONStorage.add_item(AUDIT_LOGS_FILE, audit_log.model_dump())
    
    return created_episode

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include router
app.include_router(api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=True)
