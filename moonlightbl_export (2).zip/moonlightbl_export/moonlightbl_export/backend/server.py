from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Query, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import desc, asc, or_
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import hashlib
import re
import aiofiles
import shutil

from database import get_db, create_tables, Content, Season, Episode, CarouselConfig, CarouselItem, ViewStat, AuditLog, LoginAttempt, ContactMessage
from back4app_config import config, db_url

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Create uploads directory
UPLOADS_DIR = ROOT_DIR / 'uploads'
UPLOADS_DIR.mkdir(exist_ok=True)
POSTERS_DIR = UPLOADS_DIR / 'posters'
POSTERS_DIR.mkdir(exist_ok=True)
BACKDROPS_DIR = UPLOADS_DIR / 'backdrops'
BACKDROPS_DIR.mkdir(exist_ok=True)
THUMBNAILS_DIR = UPLOADS_DIR / 'thumbnails'
THUMBNAILS_DIR.mkdir(exist_ok=True)

# Mount static files
app = FastAPI(title="MoonlightBL API")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET')
if not JWT_SECRET:
    raise ValueError("JWT_SECRET environment variable is required")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# Fixed admin credentials
ADMIN_USERNAME = "ADMINBL"
ADMIN_PASSWORD_HASH = hashlib.sha256("86@$#&bihutrfcñpKGe.jobw@bl".encode()).hexdigest()

# Site configuration dinámica para Vercel
SITE_URL = config['SITE_URL']
ADMIN_URL = config['ADMIN_URL']
API_URL = config['API_URL']
UPLOAD_URL = config['UPLOAD_URL']

# Create the main app
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create database tables
create_tables()

# ==================== MODELS ====================

class LoginRequest(BaseModel):
    username: str
    password: str
    remember_me: bool = False

class LoginResponse(BaseModel):
    token: str
    expires_at: str
    site_url: str
    admin_url: str

class ServerLink(BaseModel):
    name: str
    url: str
    embed_type: str = "iframe"
    is_active: bool = True
    subtitles: Optional[str] = None
    audio: Optional[str] = None
    quality: Optional[str] = None
    order: int = 0

class ContentBase(BaseModel):
    content_type: str
    title: str
    slug: str
    year: Optional[int] = None
    synopsis: Optional[str] = None
    genres: List[str] = []
    tags: List[str] = []
    rating: Optional[float] = None
    production_company: Optional[str] = None
    producer: Optional[str] = None
    cast: List[str] = []
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    gallery: List[str] = []
    trailer_url: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    country: Optional[str] = None
    status: str = "pending"
    is_featured: bool = False
    is_trending: bool = False
    is_popular: bool = False
    servers: List[ServerLink] = []

class ContentCreate(ContentBase):
    pass

class ContentUpdate(BaseModel):
    content_type: Optional[str] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    genres: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    rating: Optional[float] = None
    production_company: Optional[str] = None
    producer: Optional[str] = None
    cast: Optional[List[str]] = None
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    gallery: Optional[List[str]] = None
    trailer_url: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    country: Optional[str] = None
    status: Optional[str] = None
    is_featured: Optional[bool] = None
    is_trending: Optional[bool] = None
    is_popular: Optional[bool] = None
    servers: Optional[List[ServerLink]] = None

class SeasonBase(BaseModel):
    number: int
    title: Optional[str] = None
    slug: str
    custom_url: Optional[str] = None
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: str = "pending"

class SeasonCreate(SeasonBase):
    content_id: Optional[str] = None

class EpisodeBase(BaseModel):
    number: int
    title: str
    slug: str
    custom_url: Optional[str] = None
    synopsis: Optional[str] = None
    duration: Optional[int] = None
    poster: Optional[str] = None
    thumbnail: Optional[str] = None
    servers: List[ServerLink] = []
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: str = "pending"

class EpisodeCreate(EpisodeBase):
    season_id: Optional[str] = None
    content_id: Optional[str] = None

# ==================== AUTH HELPERS ====================

def create_jwt_token(username: str, remember_me: bool = False) -> tuple:
    expiration = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS * (7 if remember_me else 1))
    payload = {
        "sub": username,
        "exp": expiration,
        "iat": datetime.now(timezone.utc)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token, expiration

async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
        if username != ADMIN_USERNAME:
            raise HTTPException(status_code=401, detail="Token inválido")
        return username
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expirado")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")

def generate_slug(title: str) -> str:
    slug = title.lower()
    slug = re.sub(r'[áàäâ]', 'a', slug)
    slug = re.sub(r'[éèëê]', 'e', slug)
    slug = re.sub(r'[íìïî]', 'i', slug)
    slug = re.sub(r'[óòöô]', 'o', slug)
    slug = re.sub(r'[úùüû]', 'u', slug)
    slug = re.sub(r'[ñ]', 'n', slug)
    slug = re.sub(r'[^a-z0-9\s-]', '', slug)
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = re.sub(r'-+', '-', slug)
    return slug.strip('-')

# ==================== FILE UPLOAD HELPERS ====================

async def save_upload_file(upload_file: UploadFile, destination: Path) -> str:
    try:
        async with aiofiles.open(destination, 'wb') as f:
            content = await upload_file.read()
            await f.write(content)
        return str(destination.relative_to(ROOT_DIR))
    except Exception as e:
        logger.error(f"Error saving file: {e}")
        raise HTTPException(status_code=500, detail="Error saving file")

# ==================== AUTH ROUTES ====================

@api_router.post("/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    # Check failed attempts
    five_minutes_ago = datetime.utcnow() - timedelta(minutes=5)
    recent_failures = db.query(LoginAttempt).filter(
        LoginAttempt.username == request.username,
        LoginAttempt.success == False,
        LoginAttempt.timestamp >= five_minutes_ago
    ).count()
    
    if recent_failures >= 5:
        raise HTTPException(status_code=429, detail="Demasiados intentos fallidos. Intente de nuevo más tarde.")
    
    password_hash = hashlib.sha256(request.password.encode()).hexdigest()
    
    if request.username != ADMIN_USERNAME or password_hash != ADMIN_PASSWORD_HASH:
        # Log failed attempt
        attempt = LoginAttempt(
            id=str(uuid.uuid4()),
            username=request.username,
            success=False
        )
        db.add(attempt)
        db.commit()
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    
    # Log successful attempt
    attempt = LoginAttempt(
        id=str(uuid.uuid4()),
        username=request.username,
        success=True
    )
    db.add(attempt)
    db.commit()
    
    token, expires_at = create_jwt_token(request.username, request.remember_me)
    return LoginResponse(
        token=token, 
        expires_at=expires_at.isoformat(),
        site_url=SITE_URL,
        admin_url=ADMIN_URL
    )

@api_router.get("/auth/verify")
async def verify_auth(username: str = Depends(verify_token)):
    return {"valid": True, "username": username, "site_url": SITE_URL, "admin_url": ADMIN_URL}

# ==================== FILE UPLOAD ROUTES ====================

@api_router.post("/upload/poster")
async def upload_poster(
    file: UploadFile = File(...),
    username: str = Depends(verify_token)
):
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="El archivo debe ser una imagen")
    
    file_extension = file.filename.split('.')[-1] if '.' in file.filename else 'jpg'
    filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = POSTERS_DIR / filename
    
    relative_path = await save_upload_file(file, file_path)
    return {"url": f"{UPLOAD_URL}/{relative_path}"}

@api_router.post("/upload/backdrop")
async def upload_backdrop(
    file: UploadFile = File(...),
    username: str = Depends(verify_token)
):
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="El archivo debe ser una imagen")
    
    file_extension = file.filename.split('.')[-1] if '.' in file.filename else 'jpg'
    filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = BACKDROPS_DIR / filename
    
    relative_path = await save_upload_file(file, file_path)
    return {"url": f"{UPLOAD_URL}/{relative_path}"}

@api_router.post("/upload/thumbnail")
async def upload_thumbnail(
    file: UploadFile = File(...),
    username: str = Depends(verify_token)
):
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="El archivo debe ser una imagen")
    
    file_extension = file.filename.split('.')[-1] if '.' in file.filename else 'jpg'
    filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = THUMBNAILS_DIR / filename
    
    relative_path = await save_upload_file(file, file_path)
    return {"url": f"{UPLOAD_URL}/{relative_path}"}

# ==================== PUBLIC ROUTES ====================

@api_router.get("/")
async def root():
    return {
        "message": "MoonlightBL API v1.0 (SQLite)",
        "site_url": SITE_URL,
        "admin_url": ADMIN_URL
    }

@api_router.get("/contents", response_model=List[dict])
async def get_contents(
    content_type: Optional[str] = None,
    status: str = "published",
    genre: Optional[str] = None,
    year: Optional[int] = None,
    country: Optional[str] = None,
    search: Optional[str] = None,
    is_featured: Optional[bool] = None,
    is_trending: Optional[bool] = None,
    is_popular: Optional[bool] = None,
    limit: int = Query(default=20, le=100),
    skip: int = 0,
    sort_by: str = "created_at",
    sort_order: str = "desc",
    db: Session = Depends(get_db)
):
    query = db.query(Content).filter(Content.status == status)
    
    if content_type:
        query = query.filter(Content.content_type == content_type)
    if genre:
        # For JSON field, we need to use contains
        query = query.filter(Content.genres.contains([genre]))
    if year:
        query = query.filter(Content.year == year)
    if country:
        query = query.filter(Content.country == country)
    if is_featured is not None:
        query = query.filter(Content.is_featured == is_featured)
    if is_trending is not None:
        query = query.filter(Content.is_trending == is_trending)
    if is_popular is not None:
        query = query.filter(Content.is_popular == is_popular)
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                Content.title.ilike(search_term),
                Content.synopsis.ilike(search_term),
                Content.cast.ilike(search_term)
            )
        )
    
    # Apply sorting
    if sort_order == "desc":
        query = query.order_by(desc(getattr(Content, sort_by, Content.created_at)))
    else:
        query = query.order_by(asc(getattr(Content, sort_by, Content.created_at)))
    
    # Apply pagination
    contents = query.offset(skip).limit(limit).all()
    
    result = []
    for content in contents:
        content_dict = {
            'id': content.id,
            'content_type': content.content_type,
            'title': content.title,
            'slug': content.slug,
            'year': content.year,
            'synopsis': content.synopsis,
            'genres': content.genres or [],
            'tags': content.tags or [],
            'rating': content.rating,
            'production_company': content.production_company,
            'producer': content.producer,
            'cast': content.cast or [],
            'poster': content.poster,
            'backdrop': content.backdrop,
            'gallery': content.gallery or [],
            'trailer_url': content.trailer_url,
            'tmdb_id': content.tmdb_id,
            'imdb_id': content.imdb_id,
            'country': content.country,
            'status': content.status,
            'is_featured': content.is_featured,
            'is_trending': content.is_trending,
            'is_popular': content.is_popular,
            'views': content.views,
            'season_count': content.season_count,
            'created_at': content.created_at.isoformat() if content.created_at else None,
            'updated_at': content.updated_at.isoformat() if content.updated_at else None
        }
        result.append(content_dict)
    
    return result

@api_router.get("/contents/{slug}", response_model=dict)
async def get_content_by_slug(slug: str, db: Session = Depends(get_db)):
    content = db.query(Content).filter(Content.slug == slug, Content.status == "published").first()
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    return {
        'id': content.id,
        'content_type': content.content_type,
        'title': content.title,
        'slug': content.slug,
        'year': content.year,
        'synopsis': content.synopsis,
        'genres': content.genres or [],
        'tags': content.tags or [],
        'rating': content.rating,
        'production_company': content.production_company,
        'producer': content.producer,
        'cast': content.cast or [],
        'poster': content.poster,
        'backdrop': content.backdrop,
        'gallery': content.gallery or [],
        'trailer_url': content.trailer_url,
        'tmdb_id': content.tmdb_id,
        'imdb_id': content.imdb_id,
        'country': content.country,
        'status': content.status,
        'is_featured': content.is_featured,
        'is_trending': content.is_trending,
        'is_popular': content.is_popular,
        'views': content.views,
        'season_count': content.season_count,
        'created_at': content.created_at.isoformat() if content.created_at else None,
        'updated_at': content.updated_at.isoformat() if content.updated_at else None
    }

@api_router.get("/contents/{slug}/seasons", response_model=List[dict])
async def get_content_seasons(slug: str, db: Session = Depends(get_db)):
    content = db.query(Content).filter(Content.slug == slug).first()
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    seasons = db.query(Season).filter(Season.content_id == content.id).order_by(Season.number).all()
    
    result = []
    for season in seasons:
        season_dict = {
            'id': season.id,
            'content_id': season.content_id,
            'number': season.number,
            'title': season.title,
            'slug': season.slug,
            'custom_url': season.custom_url,
            'poster': season.poster,
            'backdrop': season.backdrop,
            'year': season.year,
            'synopsis': season.synopsis,
            'tmdb_id': season.tmdb_id,
            'imdb_id': season.imdb_id,
            'air_date': season.air_date,
            'status': season.status,
            'episode_count': season.episode_count,
            'created_at': season.created_at.isoformat() if season.created_at else None,
            'updated_at': season.updated_at.isoformat() if season.updated_at else None
        }
        result.append(season_dict)
    
    return result

@api_router.get("/seasons/{season_id}/episodes", response_model=List[dict])
async def get_season_episodes(season_id: str, db: Session = Depends(get_db)):
    season = db.query(Season).filter(Season.id == season_id).first()
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    episodes = db.query(Episode).filter(
        Episode.season_id == season_id, 
        Episode.status == "published"
    ).order_by(Episode.number).all()
    
    result = []
    for episode in episodes:
        episode_dict = {
            'id': episode.id,
            'season_id': episode.season_id,
            'content_id': episode.content_id,
            'number': episode.number,
            'title': episode.title,
            'slug': episode.slug,
            'custom_url': episode.custom_url,
            'synopsis': episode.synopsis,
            'duration': episode.duration,
            'poster': episode.poster,
            'thumbnail': episode.thumbnail,
            'servers': episode.servers or [],
            'tmdb_id': episode.tmdb_id,
            'imdb_id': episode.imdb_id,
            'air_date': episode.air_date,
            'status': episode.status,
            'views': episode.views,
            'created_at': episode.created_at.isoformat() if episode.created_at else None,
            'updated_at': episode.updated_at.isoformat() if episode.updated_at else None
        }
        result.append(episode_dict)
    
    return result

@api_router.get("/episodes/{slug}", response_model=dict)
async def get_episode_by_slug(slug: str, db: Session = Depends(get_db)):
    episode = db.query(Episode).filter(Episode.slug == slug, Episode.status == "published").first()
    if not episode:
        raise HTTPException(status_code=404, detail="Episodio no encontrado")
    
    # Increment view count
    episode.views += 1
    db.commit()
    
    # Log view stat
    view_stat = ViewStat(
        id=str(uuid.uuid4()),
        content_id=episode.content_id,
        episode_id=episode.id
    )
    db.add(view_stat)
    db.commit()
    
    return {
        'id': episode.id,
        'season_id': episode.season_id,
        'content_id': episode.content_id,
        'number': episode.number,
        'title': episode.title,
        'slug': episode.slug,
        'custom_url': episode.custom_url,
        'synopsis': episode.synopsis,
        'duration': episode.duration,
        'poster': episode.poster,
        'thumbnail': episode.thumbnail,
        'servers': episode.servers or [],
        'tmdb_id': episode.tmdb_id,
        'imdb_id': episode.imdb_id,
        'air_date': episode.air_date,
        'status': episode.status,
        'views': episode.views,
        'created_at': episode.created_at.isoformat() if episode.created_at else None,
        'updated_at': episode.updated_at.isoformat() if episode.updated_at else None
    }

@api_router.get("/carousel", response_model=List[dict])
async def get_carousel(db: Session = Depends(get_db)):
    # Get carousel config
    carousel_config = db.query(CarouselConfig).first()
    
    if not carousel_config or carousel_config.auto_populate:
        # Auto-populate based on type
        auto_type = carousel_config.auto_type if carousel_config else "popular"
        
        query = db.query(Content).filter(Content.status == "published")
        
        if auto_type == "popular":
            query = query.filter(Content.is_popular == True)
        elif auto_type == "trending":
            query = query.filter(Content.is_trending == True)
        
        contents = query.order_by(desc(Content.created_at)).limit(10).all()
        
        result = []
        for content in contents:
            content_dict = {
                'id': content.id,
                'content_type': content.content_type,
                'title': content.title,
                'slug': content.slug,
                'poster': content.poster,
                'backdrop': content.backdrop,
                'year': content.year,
                'rating': content.rating,
                'is_featured': content.is_featured,
                'is_trending': content.is_trending,
                'is_popular': content.is_popular
            }
            result.append(content_dict)
        
        return result
    else:
        # Return manually configured items
        items = db.query(CarouselItem).order_by(CarouselItem.order).all()
        result = []
        for item in items:
            content = db.query(Content).filter(
                Content.id == item.content_id, 
                Content.status == "published"
            ).first()
            if content:
                content_dict = {
                    'id': content.id,
                    'content_type': content.content_type,
                    'title': content.title,
                    'slug': content.slug,
                    'poster': content.poster,
                    'backdrop': content.backdrop,
                    'year': content.year,
                    'rating': content.rating,
                    'is_featured': content.is_featured,
                    'is_trending': content.is_trending,
                    'is_popular': content.is_popular
                }
                result.append(content_dict)
        
        return result

# ==================== ADMIN ROUTES ====================

@api_router.get("/admin/stats")
async def get_admin_stats(username: str = Depends(verify_token), db: Session = Depends(get_db)):
    total_contents = db.query(Content).count()
    total_seasons = db.query(Season).count()
    total_episodes = db.query(Episode).count()
    
    # Calculate total views
    content_views = db.query(Content).all()
    episode_views = db.query(Episode).all()
    total_views = sum(c.views for c in content_views) + sum(e.views for e in episode_views)
    
    # Content by type
    content_by_type = {}
    for content_type in ['serie', 'miniserie', 'pelicula', 'anime']:
        count = db.query(Content).filter(Content.content_type == content_type).count()
        content_by_type[content_type] = count
    
    # Recent views (last 7 days)
    seven_days_ago = datetime.utcnow() - timedelta(days=7)
    recent_views = db.query(ViewStat).filter(ViewStat.timestamp >= seven_days_ago).count()
    
    return {
        "total_contents": total_contents,
        "total_seasons": total_seasons,
        "total_episodes": total_episodes,
        "total_views": total_views,
        "content_by_type": content_by_type,
        "recent_views": recent_views,
        "site_url": SITE_URL,
        "admin_url": ADMIN_URL
    }

@api_router.get("/admin/contents", response_model=List[dict])
async def get_admin_contents(
    content_type: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(default=50, le=100),
    skip: int = 0,
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    query = db.query(Content)
    
    if content_type:
        query = query.filter(Content.content_type == content_type)
    if status:
        query = query.filter(Content.status == status)
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                Content.title.ilike(search_term),
                Content.synopsis.ilike(search_term)
            )
        )
    
    contents = query.order_by(desc(Content.created_at)).offset(skip).limit(limit).all()
    
    result = []
    for content in contents:
        content_dict = {
            'id': content.id,
            'content_type': content.content_type,
            'title': content.title,
            'slug': content.slug,
            'year': content.year,
            'synopsis': content.synopsis,
            'genres': content.genres or [],
            'tags': content.tags or [],
            'rating': content.rating,
            'poster': content.poster,
            'backdrop': content.backdrop,
            'status': content.status,
            'is_featured': content.is_featured,
            'is_trending': content.is_trending,
            'is_popular': content.is_popular,
            'views': content.views,
            'season_count': content.season_count,
            'created_at': content.created_at.isoformat() if content.created_at else None,
            'updated_at': content.updated_at.isoformat() if content.updated_at else None
        }
        result.append(content_dict)
    
    return result

@api_router.post("/admin/contents", response_model=dict)
async def create_admin_content(content: ContentCreate, username: str = Depends(verify_token), db: Session = Depends(get_db)):
    # Check if slug already exists
    existing = db.query(Content).filter(Content.slug == content.slug).first()
    if existing:
        raise HTTPException(status_code=400, detail="Slug ya existe")
    
    content_data = content.model_dump()
    content_data['id'] = str(uuid.uuid4())
    content_data['views'] = 0
    content_data['season_count'] = 0
    
    new_content = Content(**content_data)
    db.add(new_content)
    db.commit()
    db.refresh(new_content)
    
    # Log action
    audit_log = AuditLog(
        id=str(uuid.uuid4()),
        action="create",
        entity_type="content",
        entity_id=new_content.id,
        username=username
    )
    db.add(audit_log)
    db.commit()
    
    return {
        'id': new_content.id,
        'content_type': new_content.content_type,
        'title': new_content.title,
        'slug': new_content.slug,
        'created_at': new_content.created_at.isoformat() if new_content.created_at else None
    }

@api_router.put("/admin/contents/{content_id}", response_model=dict)
async def update_admin_content(
    content_id: str, 
    updates: ContentUpdate, 
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    content = db.query(Content).filter(Content.id == content_id).first()
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    update_data = updates.model_dump(exclude_unset=True)
    
    for field, value in update_data.items():
        setattr(content, field, value)
    
    content.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(content)
    
    # Log action
    audit_log = AuditLog(
        id=str(uuid.uuid4()),
        action="update",
        entity_type="content",
        entity_id=content_id,
        changes=update_data,
        username=username
    )
    db.add(audit_log)
    db.commit()
    
    return {
        'id': content.id,
        'title': content.title,
        'slug': content.slug,
        'updated_at': content.updated_at.isoformat() if content.updated_at else None
    }

@api_router.delete("/admin/contents/{content_id}")
async def delete_admin_content(
    content_id: str, 
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    content = db.query(Content).filter(Content.id == content_id).first()
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    # Delete related seasons and episodes
    seasons = db.query(Season).filter(Season.content_id == content_id).all()
    for season in seasons:
        # Delete episodes of this season
        episodes = db.query(Episode).filter(Episode.season_id == season.id).all()
        for episode in episodes:
            db.delete(episode)
        
        # Delete season
        db.delete(season)
    
    # Delete content
    db.delete(content)
    db.commit()
    
    # Log action
    audit_log = AuditLog(
        id=str(uuid.uuid4()),
        action="delete",
        entity_type="content",
        entity_id=content_id,
        username=username
    )
    db.add(audit_log)
    db.commit()
    
    return {"message": "Contenido eliminado correctamente"}

# Similar routes for seasons and episodes...
@api_router.get("/admin/seasons", response_model=List[dict])
async def get_admin_seasons(
    content_id: Optional[str] = None,
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    query = db.query(Season)
    if content_id:
        query = query.filter(Season.content_id == content_id)
    
    seasons = query.order_by(desc(Season.created_at)).all()
    
    result = []
    for season in seasons:
        season_dict = {
            'id': season.id,
            'content_id': season.content_id,
            'number': season.number,
            'title': season.title,
            'slug': season.slug,
            'poster': season.poster,
            'backdrop': season.backdrop,
            'status': season.status,
            'episode_count': season.episode_count,
            'created_at': season.created_at.isoformat() if season.created_at else None,
            'updated_at': season.updated_at.isoformat() if season.updated_at else None
        }
        result.append(season_dict)
    
    return result

@api_router.post("/admin/seasons", response_model=dict)
async def create_admin_season(
    season: SeasonCreate, 
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    # Check if slug already exists for this content
    if season.content_id:
        existing = db.query(Season).filter(
            Season.slug == season.slug,
            Season.content_id == season.content_id
        ).first()
        if existing:
            raise HTTPException(status_code=400, detail="Slug ya existe para este contenido")
    
    season_data = season.model_dump()
    season_data['id'] = str(uuid.uuid4())
    season_data['episode_count'] = 0
    
    new_season = Season(**season_data)
    db.add(new_season)
    db.commit()
    db.refresh(new_season)
    
    # Update content season count
    if season.content_id:
        season_count = db.query(Season).filter(Season.content_id == season.content_id).count()
        db.query(Content).filter(Content.id == season.content_id).update(
            {"season_count": season_count}
        )
        db.commit()
    
    # Log action
    audit_log = AuditLog(
        id=str(uuid.uuid4()),
        action="create",
        entity_type="season",
        entity_id=new_season.id,
        username=username
    )
    db.add(audit_log)
    db.commit()
    
    return {
        'id': new_season.id,
        'content_id': new_season.content_id,
        'number': new_season.number,
        'title': new_season.title,
        'slug': new_season.slug,
        'created_at': new_season.created_at.isoformat() if new_season.created_at else None
    }

@api_router.get("/admin/episodes", response_model=List[dict])
async def get_admin_episodes(
    season_id: Optional[str] = None,
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    query = db.query(Episode)
    if season_id:
        query = query.filter(Episode.season_id == season_id)
    
    episodes = query.order_by(desc(Episode.created_at)).all()
    
    result = []
    for episode in episodes:
        episode_dict = {
            'id': episode.id,
            'season_id': episode.season_id,
            'content_id': episode.content_id,
            'number': episode.number,
            'title': episode.title,
            'slug': episode.slug,
            'poster': episode.poster,
            'thumbnail': episode.thumbnail,
            'status': episode.status,
            'views': episode.views,
            'created_at': episode.created_at.isoformat() if episode.created_at else None,
            'updated_at': episode.updated_at.isoformat() if episode.updated_at else None
        }
        result.append(episode_dict)
    
    return result

@api_router.post("/admin/episodes", response_model=dict)
async def create_admin_episode(
    episode: EpisodeCreate, 
    username: str = Depends(verify_token),
    db: Session = Depends(get_db)
):
    # Check if slug already exists for this season
    if episode.season_id:
        existing = db.query(Episode).filter(
            Episode.slug == episode.slug,
            Episode.season_id == episode.season_id
        ).first()
        if existing:
            raise HTTPException(status_code=400, detail="Slug ya existe para esta temporada")
    
    episode_data = episode.model_dump()
    episode_data['id'] = str(uuid.uuid4())
    episode_data['views'] = 0
    
    new_episode = Episode(**episode_data)
    db.add(new_episode)
    db.commit()
    db.refresh(new_episode)
    
    # Update season episode count
    if episode.season_id:
        episode_count = db.query(Episode).filter(Episode.season_id == episode.season_id).count()
        db.query(Season).filter(Season.id == episode.season_id).update(
            {"episode_count": episode_count}
        )
        db.commit()
    
    # Log action
    audit_log = AuditLog(
        id=str(uuid.uuid4()),
        action="create",
        entity_type="episode",
        entity_id=new_episode.id,
        username=username
    )
    db.add(audit_log)
    db.commit()
    
    return {
        'id': new_episode.id,
        'season_id': new_episode.season_id,
        'content_id': new_episode.content_id,
        'number': new_episode.number,
        'title': new_episode.title,
        'slug': new_episode.slug,
        'created_at': new_episode.created_at.isoformat() if new_episode.created_at else None
    }

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include router
app.include_router(api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=True)
