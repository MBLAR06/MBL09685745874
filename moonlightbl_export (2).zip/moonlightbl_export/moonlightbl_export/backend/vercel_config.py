import os
from urllib.parse import urlparse

# Configuración dinámica para Vercel
def get_vercel_config():
    """
    Obtiene la configuración dinámica para Vercel
    Vercel automáticamente inyecta estas variables durante el deployment
    """
    
    # Obtener URL del deployment de Vercel
    vercel_url = os.getenv('VERCEL_URL')
    if vercel_url:
        # Si estamos en Vercel, usar la URL de Vercel
        base_url = f"https://{vercel_url}"
    else:
        # Para desarrollo local
        base_url = "http://localhost:3000"
    
    return {
        'SITE_URL': base_url,
        'ADMIN_URL': f"{base_url}/admin",
        'API_URL': f"{base_url}/api",
        'UPLOAD_URL': f"{base_url}/uploads"
    }

# Configuración de base de datos para Vercel
def get_database_url():
    """
    Retorna la URL de base de datos apropiada
    """
    # Para Vercel, podrías usar PostgreSQL externo o SQLite temporal
    if os.getenv('VERCEL'):
        # Opción 1: SQLite (para desarrollo rápido)
        return "sqlite:///./moonlightbl.db"
        
        # Opción 2: PostgreSQL (descomenta y configura)
        # postgresql_user = os.getenv('POSTGRES_USER')
        # postgresql_password = os.getenv('POSTGRES_PASSWORD')
        # postgresql_host = os.getenv('POSTGRES_HOST')
        # postgresql_database = os.getenv('POSTGRES_DATABASE')
        # if all([postgresql_user, postgresql_password, postgresql_host, postgresql_database]):
        #     return f"postgresql://{postgresql_user}:{postgresql_password}@{postgresql_host}/{postgresql_database}"
    
    # Para desarrollo local
    return "sqlite:///./moonlightbl_dev.db"

# Obtener configuración actual
config = get_vercel_config()
db_url = get_database_url()

# Exportar para uso en otros módulos
__all__ = ['config', 'db_url']
