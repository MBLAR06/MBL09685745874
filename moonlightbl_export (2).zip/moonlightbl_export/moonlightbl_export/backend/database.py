from sqlalchemy import create_engine, Column, String, Integer, DateTime, Boolean, Text, Float, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os

# Database configuration
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./moonlightbl.db")

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# Database models
class Content(Base):
    __tablename__ = "contents"
    
    id = Column(String, primary_key=True)
    content_type = Column(String, nullable=False)  # serie | miniserie | pelicula | anime
    title = Column(String, nullable=False)
    slug = Column(String, unique=True, nullable=False)
    year = Column(Integer)
    synopsis = Column(Text)
    genres = Column(JSON)  # List of strings
    tags = Column(JSON)  # List of strings
    rating = Column(Float)
    production_company = Column(String)
    producer = Column(String)
    cast = Column(JSON)  # List of strings
    poster = Column(String)
    backdrop = Column(String)
    gallery = Column(JSON)  # List of strings
    trailer_url = Column(String)
    tmdb_id = Column(String)
    imdb_id = Column(String)
    country = Column(String)
    status = Column(String, default="pending")  # pending | published
    is_featured = Column(Boolean, default=False)
    is_trending = Column(Boolean, default=False)
    is_popular = Column(Boolean, default=False)
    views = Column(Integer, default=0)
    season_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Season(Base):
    __tablename__ = "seasons"
    
    id = Column(String, primary_key=True)
    content_id = Column(String, nullable=False)
    number = Column(Integer, nullable=False)
    title = Column(String)
    slug = Column(String, nullable=False)
    custom_url = Column(String)
    poster = Column(String)
    backdrop = Column(String)
    year = Column(Integer)
    synopsis = Column(Text)
    tmdb_id = Column(String)
    imdb_id = Column(String)
    air_date = Column(String)
    status = Column(String, default="pending")
    episode_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Episode(Base):
    __tablename__ = "episodes"
    
    id = Column(String, primary_key=True)
    season_id = Column(String, nullable=False)
    content_id = Column(String, nullable=False)
    number = Column(Integer, nullable=False)
    title = Column(String, nullable=False)
    slug = Column(String, nullable=False)
    custom_url = Column(String)
    synopsis = Column(Text)
    duration = Column(Integer)
    poster = Column(String)
    thumbnail = Column(String)
    servers = Column(JSON)  # List of server links
    tmdb_id = Column(String)
    imdb_id = Column(String)
    air_date = Column(String)
    status = Column(String, default="pending")
    views = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CarouselItem(Base):
    __tablename__ = "carousel_items"
    
    id = Column(String, primary_key=True)
    content_id = Column(String, nullable=False)
    order = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class CarouselConfig(Base):
    __tablename__ = "carousel_config"
    
    id = Column(String, primary_key=True)
    items = Column(JSON)  # List of carousel items
    auto_populate = Column(Boolean, default=True)
    auto_type = Column(String, default="popular")  # popular | trending | latest
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ViewStat(Base):
    __tablename__ = "view_stats"
    
    id = Column(String, primary_key=True)
    content_id = Column(String, nullable=False)
    episode_id = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)
    user_agent = Column(String)
    ip_hash = Column(String)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(String, primary_key=True)
    action = Column(String, nullable=False)
    entity_type = Column(String, nullable=False)
    entity_id = Column(String, nullable=False)
    changes = Column(JSON)
    timestamp = Column(DateTime, default=datetime.utcnow)
    username = Column(String, default="ADMINBL")

class LoginAttempt(Base):
    __tablename__ = "login_attempts"
    
    id = Column(String, primary_key=True)
    username = Column(String, nullable=False)
    success = Column(Boolean, nullable=False)
    ip_hash = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)

class ContactMessage(Base):
    __tablename__ = "contact_messages"
    
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    subject = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    read = Column(Boolean, default=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

# Create all tables
def create_tables():
    Base.metadata.create_all(bind=engine)

# Dependency to get database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
