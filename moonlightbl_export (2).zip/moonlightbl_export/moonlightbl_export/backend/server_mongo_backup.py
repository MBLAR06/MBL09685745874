from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import hashlib
import re

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET')
if not JWT_SECRET:
    raise ValueError("JWT_SECRET environment variable is required")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# Fixed admin credentials
ADMIN_USERNAME = "ADMINBL"
ADMIN_PASSWORD_HASH = hashlib.sha256("86@$#&bihutrfcñpKGe.jobw@bl".encode()).hexdigest()

# Create the main app
app = FastAPI(title="MoonlightBL API")
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==================== MODELS ====================

class LoginRequest(BaseModel):
    username: str
    password: str
    remember_me: bool = False

class LoginResponse(BaseModel):
    token: str
    expires_at: str

class ServerLink(BaseModel):
    name: str  # Nombre del servidor (ok.ru, streamtape, etc.)
    url: str  # URL completa o código embed
    embed_type: str = "iframe"  # iframe | embed | mp4 | shortcode
    is_active: bool = True
    subtitles: Optional[str] = None  # Idioma de subtítulos
    audio: Optional[str] = None  # Idioma de audio
    quality: Optional[str] = None  # 480p, 720p, 1080p, etc.
    order: int = 0  # Orden de preferencia

class EpisodeBase(BaseModel):
    number: int
    title: str
    slug: str
    custom_url: Optional[str] = None  # URL personalizada opcional
    synopsis: Optional[str] = None
    duration: Optional[int] = None
    poster: Optional[str] = None
    thumbnail: Optional[str] = None
    servers: List[ServerLink] = []
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: str = "pending"  # pending | published

class EpisodeCreate(EpisodeBase):
    season_id: Optional[str] = None
    content_id: Optional[str] = None

class EpisodeUpdate(BaseModel):
    number: Optional[int] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    custom_url: Optional[str] = None
    synopsis: Optional[str] = None
    duration: Optional[int] = None
    poster: Optional[str] = None
    thumbnail: Optional[str] = None
    servers: Optional[List[ServerLink]] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: Optional[str] = None

class Episode(EpisodeBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    season_id: str
    content_id: str
    views: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SeasonBase(BaseModel):
    number: int
    title: Optional[str] = None
    slug: str
    custom_url: Optional[str] = None  # URL personalizada opcional
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: str = "pending"

class SeasonCreate(SeasonBase):
    content_id: Optional[str] = None

class SeasonUpdate(BaseModel):
    number: Optional[int] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    custom_url: Optional[str] = None
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    air_date: Optional[str] = None
    status: Optional[str] = None

class Season(SeasonBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content_id: str
    episode_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ContentBase(BaseModel):
    content_type: str  # serie | miniserie | pelicula | anime
    title: str
    slug: str
    year: Optional[int] = None
    synopsis: Optional[str] = None
    genres: List[str] = []
    tags: List[str] = []
    rating: Optional[float] = None
    production_company: Optional[str] = None
    producer: Optional[str] = None
    cast: List[str] = []
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    gallery: List[str] = []
    trailer_url: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    country: Optional[str] = None
    status: str = "pending"  # pending | published
    is_featured: bool = False
    is_trending: bool = False
    is_popular: bool = False
    servers: List[ServerLink] = []  # For movies only

class ContentCreate(ContentBase):
    pass

class ContentUpdate(BaseModel):
    content_type: Optional[str] = None
    title: Optional[str] = None
    slug: Optional[str] = None
    year: Optional[int] = None
    synopsis: Optional[str] = None
    genres: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    rating: Optional[float] = None
    production_company: Optional[str] = None
    producer: Optional[str] = None
    cast: Optional[List[str]] = None
    poster: Optional[str] = None
    backdrop: Optional[str] = None
    gallery: Optional[List[str]] = None
    trailer_url: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    country: Optional[str] = None
    status: Optional[str] = None
    is_featured: Optional[bool] = None
    is_trending: Optional[bool] = None
    is_popular: Optional[bool] = None
    servers: Optional[List[ServerLink]] = None

class Content(ContentBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    views: int = 0
    season_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CarouselItem(BaseModel):
    content_id: str
    order: int

class CarouselConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    items: List[CarouselItem] = []
    auto_populate: bool = True
    auto_type: str = "popular"  # popular | trending | latest
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ViewStat(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content_id: str
    episode_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    user_agent: Optional[str] = None
    ip_hash: Optional[str] = None

class AuditLog(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    action: str
    entity_type: str
    entity_id: str
    changes: Dict[str, Any] = {}
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    username: str = "ADMINBL"

class LoginAttempt(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    success: bool
    ip_hash: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ContactMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: str
    subject: str
    message: str
    read: bool = False
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# ==================== AUTH HELPERS ====================

def create_jwt_token(username: str, remember_me: bool = False) -> tuple:
    expiration = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS * (7 if remember_me else 1))
    payload = {
        "sub": username,
        "exp": expiration,
        "iat": datetime.now(timezone.utc)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token, expiration

async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
        if username != ADMIN_USERNAME:
            raise HTTPException(status_code=401, detail="Token inválido")
        return username
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expirado")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")

def generate_slug(title: str) -> str:
    slug = title.lower()
    slug = re.sub(r'[áàäâ]', 'a', slug)
    slug = re.sub(r'[éèëê]', 'e', slug)
    slug = re.sub(r'[íìïî]', 'i', slug)
    slug = re.sub(r'[óòöô]', 'o', slug)
    slug = re.sub(r'[úùüû]', 'u', slug)
    slug = re.sub(r'[ñ]', 'n', slug)
    slug = re.sub(r'[^a-z0-9\s-]', '', slug)
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = re.sub(r'-+', '-', slug)
    return slug.strip('-')

# ==================== AUTH ROUTES ====================

@api_router.post("/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    # Check failed attempts
    five_minutes_ago = datetime.now(timezone.utc) - timedelta(minutes=5)
    recent_failures = await db.login_attempts.count_documents({
        "username": request.username,
        "success": False,
        "timestamp": {"$gte": five_minutes_ago.isoformat()}
    })
    
    if recent_failures >= 5:
        raise HTTPException(status_code=429, detail="Demasiados intentos fallidos. Intente de nuevo más tarde.")
    
    password_hash = hashlib.sha256(request.password.encode()).hexdigest()
    
    if request.username != ADMIN_USERNAME or password_hash != ADMIN_PASSWORD_HASH:
        # Log failed attempt
        attempt = LoginAttempt(username=request.username, success=False)
        await db.login_attempts.insert_one({**attempt.model_dump(), "timestamp": attempt.timestamp.isoformat()})
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    
    # Log successful attempt
    attempt = LoginAttempt(username=request.username, success=True)
    await db.login_attempts.insert_one({**attempt.model_dump(), "timestamp": attempt.timestamp.isoformat()})
    
    token, expires_at = create_jwt_token(request.username, request.remember_me)
    return LoginResponse(token=token, expires_at=expires_at.isoformat())

@api_router.get("/auth/verify")
async def verify_auth(username: str = Depends(verify_token)):
    return {"valid": True, "username": username}

# ==================== PUBLIC ROUTES ====================

@api_router.get("/")
async def root():
    return {"message": "MoonlightBL API v1.0"}

@api_router.get("/contents", response_model=List[dict])
async def get_contents(
    content_type: Optional[str] = None,
    status: str = "published",
    genre: Optional[str] = None,
    year: Optional[int] = None,
    country: Optional[str] = None,
    search: Optional[str] = None,
    is_featured: Optional[bool] = None,
    is_trending: Optional[bool] = None,
    is_popular: Optional[bool] = None,
    limit: int = Query(default=20, le=100),
    skip: int = 0,
    sort_by: str = "created_at",
    sort_order: str = "desc"
):
    query = {"status": status}
    
    if content_type:
        query["content_type"] = content_type
    if genre:
        query["genres"] = {"$in": [genre]}
    if year:
        query["year"] = year
    if country:
        query["country"] = country
    if is_featured is not None:
        query["is_featured"] = is_featured
    if is_trending is not None:
        query["is_trending"] = is_trending
    if is_popular is not None:
        query["is_popular"] = is_popular
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"synopsis": {"$regex": search, "$options": "i"}},
            {"tags": {"$in": [search]}},
            {"cast": {"$regex": search, "$options": "i"}}
        ]
    
    sort_direction = -1 if sort_order == "desc" else 1
    
    contents = await db.contents.find(query, {"_id": 0}).sort(sort_by, sort_direction).skip(skip).limit(limit).to_list(limit)
    
    for content in contents:
        if isinstance(content.get('created_at'), str):
            content['created_at'] = content['created_at']
        if isinstance(content.get('updated_at'), str):
            content['updated_at'] = content['updated_at']
    
    return contents

@api_router.get("/contents/{slug}", response_model=dict)
async def get_content_by_slug(slug: str):
    content = await db.contents.find_one({"slug": slug, "status": "published"}, {"_id": 0})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    return content

@api_router.get("/contents/{slug}/seasons", response_model=List[dict])
async def get_content_seasons(slug: str):
    content = await db.contents.find_one({"slug": slug}, {"_id": 0, "id": 1})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    seasons = await db.seasons.find({"content_id": content["id"], "status": "published"}, {"_id": 0}).sort("number", 1).to_list(100)
    return seasons

@api_router.get("/contents/{slug}/seasons/{season_slug}", response_model=dict)
async def get_season_by_slug(slug: str, season_slug: str):
    content = await db.contents.find_one({"slug": slug}, {"_id": 0, "id": 1})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    season = await db.seasons.find_one({"content_id": content["id"], "slug": season_slug}, {"_id": 0})
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    return season

@api_router.get("/contents/{slug}/seasons/{season_slug}/episodes", response_model=List[dict])
async def get_season_episodes(slug: str, season_slug: str):
    content = await db.contents.find_one({"slug": slug}, {"_id": 0, "id": 1})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    season = await db.seasons.find_one({"content_id": content["id"], "slug": season_slug}, {"_id": 0, "id": 1})
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    episodes = await db.episodes.find({"season_id": season["id"], "status": "published"}, {"_id": 0}).sort("number", 1).to_list(100)
    return episodes

@api_router.get("/contents/{slug}/seasons/{season_slug}/episodes/{episode_slug}", response_model=dict)
async def get_episode_by_slug(slug: str, season_slug: str, episode_slug: str):
    content = await db.contents.find_one({"slug": slug}, {"_id": 0, "id": 1})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    season = await db.seasons.find_one({"content_id": content["id"], "slug": season_slug}, {"_id": 0, "id": 1})
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    episode = await db.episodes.find_one({"season_id": season["id"], "slug": episode_slug}, {"_id": 0})
    if not episode:
        raise HTTPException(status_code=404, detail="Episodio no encontrado")
    
    # Record view
    view_stat = ViewStat(content_id=content["id"], episode_id=episode["id"])
    await db.view_stats.insert_one({**view_stat.model_dump(), "timestamp": view_stat.timestamp.isoformat()})
    await db.episodes.update_one({"id": episode["id"]}, {"$inc": {"views": 1}})
    await db.contents.update_one({"id": content["id"]}, {"$inc": {"views": 1}})
    
    return episode

@api_router.get("/carousel", response_model=List[dict])
async def get_carousel():
    config = await db.carousel_config.find_one({}, {"_id": 0})
    
    if config and config.get("items"):
        content_ids = [item["content_id"] for item in config["items"]]
        contents = await db.contents.find({"id": {"$in": content_ids}, "status": "published"}, {"_id": 0}).to_list(10)
        # Sort by order
        id_to_order = {item["content_id"]: item["order"] for item in config["items"]}
        contents.sort(key=lambda x: id_to_order.get(x["id"], 999))
        return contents
    
    # Auto-populate with popular/trending/latest
    auto_type = config.get("auto_type", "popular") if config else "popular"
    
    if auto_type == "popular":
        contents = await db.contents.find({"status": "published", "is_popular": True}, {"_id": 0}).sort("views", -1).limit(10).to_list(10)
    elif auto_type == "trending":
        contents = await db.contents.find({"status": "published", "is_trending": True}, {"_id": 0}).sort("views", -1).limit(10).to_list(10)
    else:
        contents = await db.contents.find({"status": "published"}, {"_id": 0}).sort("created_at", -1).limit(10).to_list(10)
    
    if not contents:
        contents = await db.contents.find({"status": "published"}, {"_id": 0}).sort("created_at", -1).limit(10).to_list(10)
    
    return contents

@api_router.get("/genres", response_model=List[str])
async def get_all_genres():
    pipeline = [
        {"$match": {"status": "published"}},
        {"$unwind": "$genres"},
        {"$group": {"_id": "$genres"}},
        {"$sort": {"_id": 1}}
    ]
    result = await db.contents.aggregate(pipeline).to_list(100)
    return [r["_id"] for r in result]

@api_router.get("/countries", response_model=List[str])
async def get_all_countries():
    pipeline = [
        {"$match": {"status": "published", "country": {"$ne": None}}},
        {"$group": {"_id": "$country"}},
        {"$sort": {"_id": 1}}
    ]
    result = await db.contents.aggregate(pipeline).to_list(100)
    return [r["_id"] for r in result]

@api_router.post("/contents/{content_id}/view")
async def record_content_view(content_id: str):
    content = await db.contents.find_one({"id": content_id}, {"_id": 0})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    view_stat = ViewStat(content_id=content_id)
    await db.view_stats.insert_one({**view_stat.model_dump(), "timestamp": view_stat.timestamp.isoformat()})
    await db.contents.update_one({"id": content_id}, {"$inc": {"views": 1}})
    
    return {"success": True}

# ==================== ADMIN ROUTES ====================

@api_router.get("/admin/contents", response_model=List[dict])
async def admin_get_contents(
    username: str = Depends(verify_token),
    content_type: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(default=50, le=200),
    skip: int = 0
):
    query = {}
    if content_type:
        query["content_type"] = content_type
    if status:
        query["status"] = status
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"tmdb_id": search},
            {"imdb_id": search}
        ]
    
    contents = await db.contents.find(query, {"_id": 0}).sort("updated_at", -1).skip(skip).limit(limit).to_list(limit)
    return contents

@api_router.get("/admin/contents/{content_id}", response_model=dict)
async def admin_get_content(content_id: str, username: str = Depends(verify_token)):
    content = await db.contents.find_one({"id": content_id}, {"_id": 0})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    return content

@api_router.post("/admin/contents", response_model=dict)
async def admin_create_content(content: ContentCreate, username: str = Depends(verify_token)):
    # Check for duplicates
    if content.tmdb_id:
        existing = await db.contents.find_one({"tmdb_id": content.tmdb_id}, {"_id": 0})
        if existing:
            raise HTTPException(status_code=400, detail=f"Ya existe un contenido con este TMDB ID: {existing['title']}")
    
    if content.imdb_id:
        existing = await db.contents.find_one({"imdb_id": content.imdb_id}, {"_id": 0})
        if existing:
            raise HTTPException(status_code=400, detail=f"Ya existe un contenido con este IMDb ID: {existing['title']}")
    
    # Check slug uniqueness
    existing_slug = await db.contents.find_one({"slug": content.slug}, {"_id": 0})
    if existing_slug:
        content.slug = f"{content.slug}-{str(uuid.uuid4())[:8]}"
    
    content_obj = Content(**content.model_dump())
    doc = content_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    # Convert servers to dict format if present
    if doc.get('servers'):
        doc['servers'] = [s if isinstance(s, dict) else s.model_dump() if hasattr(s, 'model_dump') else dict(s) for s in doc['servers']]
    
    # Insert without _id issue
    insert_doc = {k: v for k, v in doc.items()}
    await db.contents.insert_one(insert_doc)
    
    # Audit log
    audit = AuditLog(action="create", entity_type="content", entity_id=content_obj.id, changes={"title": content.title})
    await db.audit_logs.insert_one({**audit.model_dump(), "timestamp": audit.timestamp.isoformat()})
    
    # Return clean doc without _id
    return {k: v for k, v in doc.items() if k != '_id'}

@api_router.put("/admin/contents/{content_id}", response_model=dict)
async def admin_update_content(content_id: str, update: ContentUpdate, username: str = Depends(verify_token)):
    existing = await db.contents.find_one({"id": content_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.contents.update_one({"id": content_id}, {"$set": update_data})
    
    # Audit log
    audit = AuditLog(action="update", entity_type="content", entity_id=content_id, changes=update_data)
    await db.audit_logs.insert_one({**audit.model_dump(), "timestamp": audit.timestamp.isoformat()})
    
    updated = await db.contents.find_one({"id": content_id}, {"_id": 0})
    return updated

@api_router.delete("/admin/contents/{content_id}")
async def admin_delete_content(content_id: str, username: str = Depends(verify_token)):
    existing = await db.contents.find_one({"id": content_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    # Delete related seasons and episodes (optimized - no N+1)
    seasons = await db.seasons.find({"content_id": content_id}, {"_id": 0, "id": 1}).to_list(100)
    if seasons:
        season_ids = [s["id"] for s in seasons]
        await db.episodes.delete_many({"season_id": {"$in": season_ids}})
    await db.seasons.delete_many({"content_id": content_id})
    await db.contents.delete_one({"id": content_id})
    
    # Audit log
    audit = AuditLog(action="delete", entity_type="content", entity_id=content_id, changes={"title": existing.get("title")})
    await db.audit_logs.insert_one({**audit.model_dump(), "timestamp": audit.timestamp.isoformat()})
    
    return {"success": True}

# Season Management
@api_router.get("/admin/contents/{content_id}/seasons", response_model=List[dict])
async def admin_get_seasons(content_id: str, username: str = Depends(verify_token)):
    seasons = await db.seasons.find({"content_id": content_id}, {"_id": 0}).sort("number", 1).to_list(100)
    return seasons

@api_router.post("/admin/contents/{content_id}/seasons", response_model=dict)
async def admin_create_season(content_id: str, season: SeasonCreate, username: str = Depends(verify_token)):
    content = await db.contents.find_one({"id": content_id}, {"_id": 0})
    if not content:
        raise HTTPException(status_code=404, detail="Contenido no encontrado")
    
    if content.get("content_type") == "pelicula":
        raise HTTPException(status_code=400, detail="Las películas no pueden tener temporadas")
    
    # Check slug uniqueness within content
    existing_slug = await db.seasons.find_one({"content_id": content_id, "slug": season.slug}, {"_id": 0})
    if existing_slug:
        season.slug = f"{season.slug}-{str(uuid.uuid4())[:8]}"
    
    season_obj = Season(**season.model_dump(), content_id=content_id)
    doc = season_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    # Insert without _id issue
    insert_doc = {k: v for k, v in doc.items()}
    await db.seasons.insert_one(insert_doc)
    await db.contents.update_one({"id": content_id}, {"$inc": {"season_count": 1}})
    
    return {k: v for k, v in doc.items() if k != '_id'}

@api_router.put("/admin/seasons/{season_id}", response_model=dict)
async def admin_update_season(season_id: str, update: SeasonCreate, username: str = Depends(verify_token)):
    existing = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    update_data = update.model_dump()
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.seasons.update_one({"id": season_id}, {"$set": update_data})
    
    updated = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    return updated

@api_router.delete("/admin/seasons/{season_id}")
async def admin_delete_season(season_id: str, username: str = Depends(verify_token)):
    existing = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    await db.episodes.delete_many({"season_id": season_id})
    await db.seasons.delete_one({"id": season_id})
    await db.contents.update_one({"id": existing["content_id"]}, {"$inc": {"season_count": -1}})
    
    return {"success": True}

# Episode Management
@api_router.get("/admin/seasons/{season_id}/episodes", response_model=List[dict])
async def admin_get_episodes(season_id: str, username: str = Depends(verify_token)):
    episodes = await db.episodes.find({"season_id": season_id}, {"_id": 0}).sort("number", 1).to_list(100)
    return episodes

@api_router.post("/admin/seasons/{season_id}/episodes", response_model=dict)
async def admin_create_episode(season_id: str, episode: EpisodeCreate, username: str = Depends(verify_token)):
    season = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    # Check slug uniqueness within season
    existing_slug = await db.episodes.find_one({"season_id": season_id, "slug": episode.slug}, {"_id": 0})
    if existing_slug:
        raise HTTPException(status_code=400, detail="Este episodio ya está en esta temporada")
    
    episode_data = episode.model_dump()
    episode_data.pop('season_id', None)
    episode_data.pop('content_id', None)
    
    episode_obj = Episode(**episode_data, season_id=season_id, content_id=season["content_id"])
    doc = episode_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    # Convert servers to dict format if present
    if doc.get('servers'):
        doc['servers'] = [s if isinstance(s, dict) else s.model_dump() if hasattr(s, 'model_dump') else dict(s) for s in doc['servers']]
    
    # Insert without _id issue
    insert_doc = {k: v for k, v in doc.items()}
    await db.episodes.insert_one(insert_doc)
    await db.seasons.update_one({"id": season_id}, {"$inc": {"episode_count": 1}})
    
    return {k: v for k, v in doc.items() if k != '_id'}

@api_router.put("/admin/episodes/{episode_id}", response_model=dict)
async def admin_update_episode(episode_id: str, update: EpisodeUpdate, username: str = Depends(verify_token)):
    existing = await db.episodes.find_one({"id": episode_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Episodio no encontrado")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    # Convert servers to dict format if present
    if update_data.get('servers'):
        update_data['servers'] = [s if isinstance(s, dict) else s.model_dump() if hasattr(s, 'model_dump') else dict(s) for s in update_data['servers']]
    
    await db.episodes.update_one({"id": episode_id}, {"$set": update_data})
    
    updated = await db.episodes.find_one({"id": episode_id}, {"_id": 0})
    return updated

@api_router.delete("/admin/episodes/{episode_id}")
async def admin_delete_episode(episode_id: str, username: str = Depends(verify_token)):
    existing = await db.episodes.find_one({"id": episode_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Episodio no encontrado")
    
    await db.episodes.delete_one({"id": episode_id})
    await db.seasons.update_one({"id": existing["season_id"]}, {"$inc": {"episode_count": -1}})
    
    return {"success": True}

# ============ INDEPENDENT SEASONS & EPISODES MANAGEMENT ============

# Get all seasons (for independent management)
@api_router.get("/admin/all-seasons", response_model=List[dict])
async def admin_get_all_seasons(
    username: str = Depends(verify_token),
    content_id: Optional[str] = None,
    tmdb_id: Optional[str] = None,
    imdb_id: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(default=50, le=200),
    skip: int = 0
):
    query = {}
    if content_id:
        query["content_id"] = content_id
    if tmdb_id:
        query["tmdb_id"] = tmdb_id
    if imdb_id:
        query["imdb_id"] = imdb_id
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"tmdb_id": search},
            {"imdb_id": search}
        ]
    
    seasons = await db.seasons.find(query, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    
    # Add content info to each season
    for season in seasons:
        content = await db.contents.find_one({"id": season.get("content_id")}, {"_id": 0, "title": 1, "content_type": 1, "slug": 1})
        season["content_title"] = content.get("title") if content else "N/A"
        season["content_type"] = content.get("content_type") if content else "N/A"
        season["content_slug"] = content.get("slug") if content else ""
    
    return seasons

# Get all episodes (for independent management)
@api_router.get("/admin/all-episodes", response_model=List[dict])
async def admin_get_all_episodes(
    username: str = Depends(verify_token),
    season_id: Optional[str] = None,
    content_id: Optional[str] = None,
    tmdb_id: Optional[str] = None,
    imdb_id: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(default=50, le=200),
    skip: int = 0
):
    query = {}
    if season_id:
        query["season_id"] = season_id
    if content_id:
        query["content_id"] = content_id
    if tmdb_id:
        query["tmdb_id"] = tmdb_id
    if imdb_id:
        query["imdb_id"] = imdb_id
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"tmdb_id": search},
            {"imdb_id": search}
        ]
    
    episodes = await db.episodes.find(query, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    
    # Add content and season info to each episode
    for episode in episodes:
        season = await db.seasons.find_one({"id": episode.get("season_id")}, {"_id": 0, "number": 1, "title": 1})
        content = await db.contents.find_one({"id": episode.get("content_id")}, {"_id": 0, "title": 1, "content_type": 1, "slug": 1})
        episode["season_number"] = season.get("number") if season else 0
        episode["season_title"] = season.get("title") if season else ""
        episode["content_title"] = content.get("title") if content else "N/A"
        episode["content_type"] = content.get("content_type") if content else "N/A"
        episode["content_slug"] = content.get("slug") if content else ""
    
    return episodes

# Get single episode
@api_router.get("/admin/episodes/{episode_id}", response_model=dict)
async def admin_get_episode(episode_id: str, username: str = Depends(verify_token)):
    episode = await db.episodes.find_one({"id": episode_id}, {"_id": 0})
    if not episode:
        raise HTTPException(status_code=404, detail="Episodio no encontrado")
    
    # Add related info
    season = await db.seasons.find_one({"id": episode.get("season_id")}, {"_id": 0, "number": 1, "title": 1, "slug": 1})
    content = await db.contents.find_one({"id": episode.get("content_id")}, {"_id": 0, "title": 1, "content_type": 1, "slug": 1})
    episode["season_number"] = season.get("number") if season else 0
    episode["season_title"] = season.get("title") if season else ""
    episode["season_slug"] = season.get("slug") if season else ""
    episode["content_title"] = content.get("title") if content else "N/A"
    episode["content_type"] = content.get("content_type") if content else "N/A"
    episode["content_slug"] = content.get("slug") if content else ""
    
    return episode

# Get single season
@api_router.get("/admin/seasons/{season_id}", response_model=dict)
async def admin_get_season(season_id: str, username: str = Depends(verify_token)):
    season = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    if not season:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    # Add content info
    content = await db.contents.find_one({"id": season.get("content_id")}, {"_id": 0, "title": 1, "content_type": 1, "slug": 1})
    season["content_title"] = content.get("title") if content else "N/A"
    season["content_type"] = content.get("content_type") if content else "N/A"
    season["content_slug"] = content.get("slug") if content else ""
    
    return season

# Update season with SeasonUpdate model
@api_router.put("/admin/seasons/{season_id}/update", response_model=dict)
async def admin_update_season_full(season_id: str, update: SeasonUpdate, username: str = Depends(verify_token)):
    existing = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="Temporada no encontrada")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.seasons.update_one({"id": season_id}, {"$set": update_data})
    
    updated = await db.seasons.find_one({"id": season_id}, {"_id": 0})
    return updated

# Carousel Management
@api_router.get("/admin/carousel", response_model=dict)
async def admin_get_carousel_config(username: str = Depends(verify_token)):
    config = await db.carousel_config.find_one({}, {"_id": 0})
    if not config:
        config_obj = CarouselConfig()
        config = config_obj.model_dump()
        config['updated_at'] = config['updated_at'].isoformat()
        # Don't insert yet, just return default
        return config
    # Ensure updated_at is string
    if hasattr(config.get('updated_at'), 'isoformat'):
        config['updated_at'] = config['updated_at'].isoformat()
    return config

@api_router.put("/admin/carousel", response_model=dict)
async def admin_update_carousel(config: dict, username: str = Depends(verify_token)):
    config["updated_at"] = datetime.now(timezone.utc).isoformat()
    await db.carousel_config.update_one({}, {"$set": config}, upsert=True)
    updated = await db.carousel_config.find_one({}, {"_id": 0})
    return updated

# Statistics
@api_router.get("/admin/stats/overview")
async def admin_stats_overview(username: str = Depends(verify_token)):
    total_contents = await db.contents.count_documents({})
    published_contents = await db.contents.count_documents({"status": "published"})
    pending_contents = await db.contents.count_documents({"status": "pending"})
    
    series_count = await db.contents.count_documents({"content_type": "serie"})
    miniseries_count = await db.contents.count_documents({"content_type": "miniserie"})
    movies_count = await db.contents.count_documents({"content_type": "pelicula"})
    anime_count = await db.contents.count_documents({"content_type": "anime"})
    
    total_seasons = await db.seasons.count_documents({})
    total_episodes = await db.episodes.count_documents({})
    total_views = await db.view_stats.count_documents({})
    
    return {
        "total_contents": total_contents,
        "published_contents": published_contents,
        "pending_contents": pending_contents,
        "series_count": series_count,
        "miniseries_count": miniseries_count,
        "movies_count": movies_count,
        "anime_count": anime_count,
        "total_seasons": total_seasons,
        "total_episodes": total_episodes,
        "total_views": total_views
    }

@api_router.get("/admin/stats/top-contents")
async def admin_top_contents(
    period: str = "all",  # day, week, month, year, all
    limit: int = 10,
    username: str = Depends(verify_token)
):
    now = datetime.now(timezone.utc)
    
    if period == "day":
        start_date = now - timedelta(days=1)
    elif period == "week":
        start_date = now - timedelta(weeks=1)
    elif period == "month":
        start_date = now - timedelta(days=30)
    elif period == "year":
        start_date = now - timedelta(days=365)
    else:
        start_date = None
    
    if start_date:
        pipeline = [
            {"$match": {"timestamp": {"$gte": start_date.isoformat()}}},
            {"$group": {"_id": "$content_id", "views": {"$sum": 1}}},
            {"$sort": {"views": -1}},
            {"$limit": limit}
        ]
    else:
        # Get from contents directly for all-time
        top_contents = await db.contents.find({}, {"_id": 0, "id": 1, "title": 1, "poster": 1, "views": 1, "content_type": 1}).sort("views", -1).limit(limit).to_list(limit)
        return top_contents
    
    result = await db.view_stats.aggregate(pipeline).to_list(limit)
    
    # Get content details
    content_ids = [r["_id"] for r in result]
    contents = await db.contents.find({"id": {"$in": content_ids}}, {"_id": 0, "id": 1, "title": 1, "poster": 1, "content_type": 1}).to_list(limit)
    content_map = {c["id"]: c for c in contents}
    
    top_list = []
    for r in result:
        content = content_map.get(r["_id"], {})
        top_list.append({
            **content,
            "views": r["views"]
        })
    
    return top_list

@api_router.get("/admin/stats/views-by-period")
async def admin_views_by_period(
    period: str = "week",  # day, week, month
    username: str = Depends(verify_token)
):
    now = datetime.now(timezone.utc)
    
    if period == "day":
        days = 24
        group_format = "%Y-%m-%d %H:00"
    elif period == "week":
        days = 7
        group_format = "%Y-%m-%d"
    else:
        days = 30
        group_format = "%Y-%m-%d"
    
    start_date = now - timedelta(days=days)
    
    # Simple count per day
    views_data = []
    for i in range(days):
        date = start_date + timedelta(days=i)
        next_date = date + timedelta(days=1)
        count = await db.view_stats.count_documents({
            "timestamp": {
                "$gte": date.isoformat(),
                "$lt": next_date.isoformat()
            }
        })
        views_data.append({
            "date": date.strftime("%Y-%m-%d"),
            "views": count
        })
    
    return views_data

@api_router.get("/admin/audit-logs")
async def admin_audit_logs(
    limit: int = 50,
    skip: int = 0,
    username: str = Depends(verify_token)
):
    logs = await db.audit_logs.find({}, {"_id": 0}).sort("timestamp", -1).skip(skip).limit(limit).to_list(limit)
    return logs

# Contact Form
class ContactRequest(BaseModel):
    name: str
    email: str
    subject: str
    message: str

@api_router.post("/contact")
async def submit_contact(request: ContactRequest):
    contact = ContactMessage(
        name=request.name,
        email=request.email,
        subject=request.subject,
        message=request.message
    )
    doc = contact.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    
    await db.contact_messages.insert_one(doc)
    
    # TODO: Send email when RESEND_API_KEY is configured
    # For now, messages are stored in database
    
    return {"success": True, "message": "Mensaje enviado correctamente"}

@api_router.get("/admin/contact-messages")
async def admin_get_contact_messages(
    limit: int = 50,
    skip: int = 0,
    username: str = Depends(verify_token)
):
    messages = await db.contact_messages.find({}, {"_id": 0}).sort("timestamp", -1).skip(skip).limit(limit).to_list(limit)
    return messages

@api_router.put("/admin/contact-messages/{message_id}/read")
async def admin_mark_message_read(message_id: str, username: str = Depends(verify_token)):
    await db.contact_messages.update_one({"id": message_id}, {"$set": {"read": True}})
    return {"success": True}

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
