#!/bin/bash

# Script de Deployment para Back4App
echo "🚀 Iniciando deployment de MoonlightBL a Back4App..."

# Verificar si tenemos git
if ! command -v git &> /dev/null; then
    echo "❌ Git no está instalado. Por favor instala Git primero."
    exit 1
fi

# Verificar si estamos en un repositorio git
if ! git rev-parse --git-dir > /dev/null 2>&1; then
    echo "❌ No estás en un repositorio Git. Inicializando..."
    git init
    git add .
    git commit -m "Initial commit - MoonlightBL para Back4App"
fi

# Verificar si hay cambios pendientes
if [ -n "$(git status --porcelain)" ]; then
    echo "📝 Guardando cambios..."
    git add .
    git commit -m "Deployment automático - $(date)"
fi

# Verificar si hay remote configurado
if ! git remote get-url origin > /dev/null 2>&1; then
    echo "🔗 Configurando remote..."
    echo "Por favor, configura tu repositorio de GitHub/GitLab:"
    echo "git remote add origin https://github.com/tu-usuario/moonlightbl.git"
    echo "Luego ejecuta este script nuevamente."
    exit 1
fi

# Hacer push
echo "📤 Enviando cambios..."
git push origin main

echo "✅ Deployment iniciado! Ve a https://www.back4app.com para completar."
echo ""
echo "📋 Próximos pasos:"
echo "1. Ve a https://www.back4app.com"
echo "2. Crea una nueva aplicación 'MoonlightBL'"
echo "3. Conecta tu repositorio de GitHub/GitLab"
echo "4. Configura las variables de entorno:"
echo "   JWT_SECRET=moonlightbl_prod_secret_key_x7k9m2p4q8r1s5t0u3v6w9y2z5a8b1c4"
echo "   PARSE_APPLICATION_ID=tu-app-id-back4app"
echo "   PARSE_MASTER_KEY=tu-master-key-back4app"
echo ""
echo "🎉 Back4App detectará automáticamente tu proyecto y lo desplegará!"
