# MoonlightBL - Plataforma de Catálogo BL/LGBT

## Descripción
Plataforma de catálogo y visualización de series BL, miniseries, películas y anime LGBT con panel de administración completo.

**Versión Back4App Optimizada**: Esta versión ha sido completamente configurada para deployment en Back4App con URLs dinámicas que se ajustan automáticamente durante el deployment.

## Stack Tecnológico
- **Backend**: FastAPI (Python) + SQLAlchemy + SQLite
- **Frontend**: React + TailwindCSS + Shadcn/UI
- **Base de datos**: Parse Server (Back4App) + SQLite local
- **Deployment**: Back4App Cloud Platform
- **URLs Dinámicas**: Se ajustan automáticamente al dominio de Back4App

## 🚀 Deployment en Back4App

### URLs Automáticas (Back4App las asigna automáticamente)
- **Sitio Principal**: `https://moonlightbl.back4app.io`
- **Panel Administrativo**: `https://moonlightbl.back4app.io/admin`
- **API Backend**: `https://moonlightbl.back4app.io/api`
- **Parse Dashboard**: `https://parse.back4app.com/apps/tu-app-id`

### Configuración Automática
El proyecto está configurado para detectar automáticamente cuando está en Back4App y ajustar todas las URLs dinámicamente usando las variables de entorno que Back4App inyecta automáticamente.

## Requisitos Previos
- Python 3.9+
- Node.js 18+
- Cuenta de Back4App

## 📋 Pasos para Deployment en Back4App

### 1. Preparar el Repositorio
```bash
# Asegúrate de que todo esté commit
git add .
git commit -m "Configuración para Back4App"
git push
```

### 2. Deployment en Back4App
1. Ve a [back4app.com](https://www.back4app.com)
2. Crea una nueva aplicación "MoonlightBL"
3. Conecta tu repositorio de GitHub/GitLab
4. Back4App detectará automáticamente que es un proyecto React + Python
5. Las URLs se configurarán automáticamente

### 3. Variables de Entorno en Back4App
Configura estas variables en el dashboard de Back4App:
```
JWT_SECRET=moonlightbl_prod_secret_key_x7k9m2p4q8r1s5t0u3v6w9y2z5a8b1c4
PARSE_APPLICATION_ID=tu-app-id-back4app
PARSE_MASTER_KEY=tu-master-key-back4app
BACK4APP_URL=https://moonlightbl.back4app.io
```

## 🔧 Desarrollo Local

### 1. Backend
```bash
cd backend
pip install -r requirements.txt
python server.py
```

### 2. Frontend
```bash
cd frontend
yarn install
yarn start
```

## 📁 Estructura de Archivos para Back4App

```
moonlightbl_export/
├── backend/
│   ├── server.py (API para Back4App)
│   ├── database.py (SQLite + SQLAlchemy)
│   ├── back4app_config.py (Configuración dinámica)
│   └── .env (Producción)
├── frontend/
│   ├── build/ (Output para Back4App)
│   ├── .env (Producción Back4App)
│   └── .env.local (Desarrollo local)
├── back4app.json (Configuración de deployment)
└── README.md
```

## 🌟 Características Especiales para Back4App

- ✅ **URLs Dinámicas**: Se ajustan automáticamente al dominio
- ✅ **Parse Server**: Base de datos NoSQL robusta y escalable
- ✅ **Zero Config**: Back4App detecta todo automáticamente
- ✅ **Archivos Estáticos**: Uploads funcionan en producción
- ✅ **Base de Datos**: Parse Server con dashboard incluido
- ✅ **CORS Configurado**: Funciona en cualquier dominio
- ✅ **Real-time**: Soporte para tiempo real
- ✅ **Push Notifications**: Listo para notificaciones
- ✅ **Dashboard Completo**: Gestión visual de datos

## 🔐 Acceso Administrativo

- **Usuario**: ADMINBL
- **Contraseña**: 86@$#&bihutrfcñpKGe.jobw@bl
- **URL**: `https://moonlightbl.back4app.io/admin`

## 📊 Dashboard de Parse

Back4App te da acceso a un dashboard completo para:
- **Gestionar datos** de tu base de datos
- **Ver logs** y estadísticas
- **Configurar permisos** de acceso
- **Monitorear rendimiento** de la API

## 📝 Notas Importantes

1. **Back4App asignará automáticamente un dominio** como `moonlightbl.back4app.io`
2. **Puedes conectar un dominio personalizado** en el dashboard de Back4App
3. **Todas las URLs se ajustan dinámicamente** sin necesidad de cambios manuales
4. **El proyecto es 100% compatible** con el ecosistema de Back4App
5. **Parse Server te da una base de datos NoSQL robusta** con dashboard incluido

**Listo para deployment en Back4App con URLs automáticas!** 🎉

## 📖 Documentación Adicional

Para instrucciones detalladas paso a paso, revisa el archivo `DEPLOYMENT_BACK4APP.md`

## Credenciales de Administrador
- **Usuario**: ADMINBL
- **Contraseña**: 86@$#&bihutrfcñpKGe.jobw@bl

## Estructura del Proyecto
```
moonlightbl/
├── backend/
│   ├── .env
│   ├── requirements.txt
│   └── server.py
├── frontend/
│   ├── .env
│   ├── package.json
│   ├── public/
│   └── src/
│       ├── components/
│       ├── lib/
│       └── pages/
└── README.md
```

## Características Principales

### Público
- Página de inicio con carrusel
- Catálogos por tipo (Series, Miniseries, Películas, Anime)
- Fichas de contenido detalladas
- Reproductor de video con múltiples servidores
- Búsqueda y filtros
- Páginas legales y de contacto

### Panel de Administración
- Dashboard con estadísticas
- CRUD completo de contenidos
- Gestión independiente de temporadas
- Gestión independiente de episodios con fuentes de video
- Configuración del carrusel
- Estadísticas y gráficos

## API Endpoints Principales

### Autenticación
- POST /api/auth/login

### Público
- GET /api/contents
- GET /api/contents/{slug}
- GET /api/carousel

### Admin (requiere autenticación)
- GET/POST/PUT/DELETE /api/admin/contents
- GET/POST/PUT/DELETE /api/admin/seasons
- GET/POST/PUT/DELETE /api/admin/episodes

## Licencia
Proyecto privado - Todos los derechos reservados
