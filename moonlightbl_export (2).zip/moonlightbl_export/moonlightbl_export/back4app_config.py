import os
from urllib.parse import urlparse

# Configuración dinámica para Back4App
def get_back4app_config():
    """
    Obtiene la configuración dinámica para Back4App
    Back4App automáticamente inyecta estas variables durante el deployment
    """
    
    # Obtener URL del deployment de Back4App
    back4app_url = os.getenv('BACK4APP_URL')
    if back4app_url:
        # Si estamos en Back4App, usar la URL de Back4App
        base_url = back4app_url
    else:
        # Para desarrollo local
        base_url = "http://localhost:3000"
    
    return {
        'SITE_URL': base_url,
        'ADMIN_URL': f"{base_url}/admin",
        'API_URL': f"{base_url}/api",
        'UPLOAD_URL': f"{base_url}/uploads"
    }

# Configuración de base de datos para Back4App
def get_database_url():
    """
    Retorna la URL de base de datos apropiada para Back4App
    """
    # Para Back4App, usaremos Parse Server
    if os.getenv('BACK4APP'):
        # Configuración de Parse Server
        parse_server_url = os.getenv('PARSE_SERVER_URL', 'https://parseapi.back4app.com')
        parse_app_id = os.getenv('PARSE_APPLICATION_ID')
        parse_master_key = os.getenv('PARSE_MASTER_KEY')
        
        if all([parse_server_url, parse_app_id, parse_master_key]):
            return f"parse://{parse_server_url}?applicationId={parse_app_id}&masterKey={parse_master_key}"
        else:
            # Fallback a SQLite para desarrollo
            return "sqlite:///./moonlightbl.db"
    
    # Para desarrollo local
    return "sqlite:///./moonlightbl_dev.db"

# Obtener configuración actual
config = get_back4app_config()
db_url = get_database_url()

# Exportar para uso en otros módulos
__all__ = ['config', 'db_url']
