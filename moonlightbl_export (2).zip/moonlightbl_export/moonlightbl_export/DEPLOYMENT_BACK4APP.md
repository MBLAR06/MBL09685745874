# 🚀 Deployment de MoonlightBL en Back4App

## 📋 Pasos Fáciles para Deployment

### Paso 1: Preparar el Repositorio

```bash
# Navega a la carpeta del proyecto
cd moonlightbl_export

# Inicializa Git si no está hecho
git init

# Agrega todos los archivos
git add .

# Haz el primer commit
git commit -m "MoonlightBL listo para Back4App"
```

### Paso 2: Subir a GitHub/GitLab

**Opción A: GitHub**
1. Ve a [github.com](https://github.com)
2. Crea un nuevo repositorio llamado `moonlightbl`
3. Sigue las instrucciones de GitHub para subir tu código:
   ```bash
   git remote add origin https://github.com/tu-usuario/moonlightbl.git
   git branch -M main
   git push -u origin main
   ```

**Opción B: GitLab**
1. Ve a [gitlab.com](https://gitlab.com)
2. Crea un nuevo proyecto llamado `moonlightbl`
3. Sube tu código:
   ```bash
   git remote add origin https://gitlab.com/tu-usuario/moonlightbl.git
   git branch -M main
   git push -u origin main
   ```

### Paso 3: Crear Aplicación en Back4App

1. **Ve a [back4app.com](https://www.back4app.com)**
2. **Inicia sesión o crea una cuenta**
3. **Haz clic en "Build a New App"**
4. **Selecciona "Web App"**
5. **Dale un nombre a tu aplicación**: `MoonlightBL`
6. **Selecciona tu plan** (puedes empezar con el plan gratuito)

### Paso 4: Conectar Repositorio

1. **En el dashboard de Back4App, ve a "Source Code"**
2. **Selecciona "GitHub" o "GitLab"**
3. **Autoriza Back4App para acceder a tu repositorio**
4. **Selecciona tu repositorio `moonlightbl`**
5. **Back4App detectará automáticamente:**
   - ✅ Framework: React (frontend)
   - ✅ Backend: Python/FastAPI
   - ✅ Build settings
   - ✅ Database: Parse Server

### Paso 5: Configurar Variables de Entorno

En el dashboard de Back4App, ve a **App Settings → Environment Variables** y agrega:

```
JWT_SECRET=moonlightbl_prod_secret_key_x7k9m2p4q8r1s5t0u3v6w9y2z5a8b1c4
PARSE_APPLICATION_ID=tu-app-id-back4app
PARSE_MASTER_KEY=tu-master-key-back4app
BACK4APP_URL=https://moonlightbl.back4app.io
```

**Nota**: Los valores `PARSE_APPLICATION_ID` y `PARSE_MASTER_KEY` los obtendrás del dashboard de Back4App después de crear la aplicación.

### Paso 6: Deployment Automático

¡Listo! Back4App hará deployment automáticamente y te dará tus URLs:

🎯 **URLs que recibirás:**
- **Sitio Principal**: `https://moonlightbl.back4app.io`
- **Panel Admin**: `https://moonlightbl.back4app.io/admin`
- **API Backend**: `https://moonlightbl.back4app.io/api`
- **Parse Dashboard**: `https://parse.back4app.com/apps/tu-app-id`

## 🛠️ Script Automático (Opcional)

Si quieres usar el script automático:

```bash
# Hazlo ejecutable
chmod +x deploy_back4app.sh

# Ejecútalo
./deploy_back4app.sh
```

## 📁 Estructura de Archivos para Back4App

```
moonlightbl_export/
├── backend/
│   ├── server.py (API para Back4App)
│   ├── database.py (SQLite + SQLAlchemy)
│   ├── back4app_config.py (Configuración dinámica)
│   └── .env (Producción)
├── frontend/
│   ├── build/ (Output para Back4App)
│   ├── .env (Producción Back4App)
│   └── .env.local (Desarrollo local)
├── back4app.json (Configuración de deployment)
└── README.md
```

## 🔧 Solución de Problemas Comunes

### Si Back4App no detecta el framework:

Asegúrate que tu `back4app.json` esté en la raíz del proyecto:

```json
{
  "back4app": {
    "appName": "MoonlightBL",
    "appType": "web",
    "buildCommand": "cd frontend && npm run build",
    "startCommand": "python backend/server.py"
  }
}
```

### Si hay errores de build:

Verifica que todas las dependencias estén instaladas:

```bash
# Frontend
cd frontend && npm install

# Backend
cd backend && pip install -r requirements.txt
```

### Si la base de datos no funciona:

1. Revisa que las credenciales de Parse estén configuradas
2. Ve al dashboard de Parse en Back4App
3. Configura las clases de datos necesarias
4. Verifica los permisos de acceso

### Si las URLs no funcionan:

1. Espera unos minutos a que el deployment termine
2. Revisa el dashboard de Back4App para ver el estado
3. Las URLs pueden tardar unos minutos en activarse

## 🌟 Características Especiales para Back4App

- ✅ **URLs Dinámicas**: Se ajustan automáticamente al dominio
- ✅ **Parse Server**: Base de datos robusta y escalable
- ✅ **Zero Config**: Back4App detecta todo automáticamente
- ✅ **Archivos Estáticos**: Uploads funcionan en producción
- ✅ **Base de Datos**: Parse Server con dashboard incluido
- ✅ **CORS Configurado**: Funciona en cualquier dominio
- ✅ **Real-time**: Soporte para tiempo real
- ✅ **Push Notifications**: Listo para notificaciones

## 🔐 Acceso Administrativo

- **Usuario**: ADMINBL
- **Contraseña**: 86@$#&bihutrfcñpKGe.jobw@bl
- **URL**: `https://moonlightbl.back4app.io/admin`

## 📊 Dashboard de Parse

Back4App te da acceso a un dashboard completo para:
- **Gestionar datos** de tu base de datos
- **Ver logs** y estadísticas
- **Configurar permisos** de acceso
- **Monitorear rendimiento** de la API

## 📝 Notas Importantes

1. **Back4App asignará automáticamente un dominio** como `moonlightbl.back4app.io`
2. **Puedes conectar un dominio personalizado** en el dashboard de Back4App
3. **Todas las URLs se ajustan dinámicamente** sin necesidad de cambios manuales
4. **El proyecto es 100% compatible** con el ecosistema de Back4App
5. **Parse Server te da una base de datos NoSQL robusta** con dashboard incluido

**¡Tu plataforma BL/LGBT estará lista para el mundo en Back4App!** 🌈🏳‍🌈
